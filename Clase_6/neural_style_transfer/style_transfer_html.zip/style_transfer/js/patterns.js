/* =========================================================================
   patterns.js — kernels "especializados" simulados (diseñados a mano):
   · Capítulo 4: qué parte de una imagen enciende cada kernel
   · Capítulo 7: hallar, desde ruido, la imagen que maximiza un feature map
                 (loss = 1 − promedio del feature map, optimizador Adam)
   · Capítulo 10: extraer el estilo de una imagen
   Todas las imágenes y feature maps están normalizados a [0,1]: 0 = negro, 1 = blanco.
   ========================================================================= */
'use strict';

const PAT = {};

/* ---------- Imágenes de prueba (blanco sobre negro) ---------- */
PAT.render = function (draw, S) {
  const c = document.createElement('canvas'); c.width = c.height = S;
  const g = c.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
  g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineWidth = 2.6 * S / 128;
  g.save(); g.scale(S / 128, S / 128); draw(g); g.restore();
  const d = g.getImageData(0, 0, S, S).data, t = new Float32Array(S * S);
  for (let i = 0; i < S * S; i++) t[i] = d[i * 4] / 255;
  return t;
};
function diagLines(g, x0, y0, w, h) { // líneas ╱ con periodo perpendicular de 6 px
  g.save(); g.beginPath(); g.rect(x0, y0, w, h); g.clip(); g.lineWidth = 2.6;
  for (let k = -260; k < 260; k += 6 * Math.SQRT2) { g.beginPath(); g.moveTo(k, 128); g.lineTo(k + 128, 0); g.stroke(); }
  g.restore();
}
function hLines(g, x0, y0, w, h) { g.save(); g.beginPath(); g.rect(x0, y0, w, h); g.clip(); g.lineWidth = 2.6; for (let y = 1; y < 128; y += 6) { g.beginPath(); g.moveTo(0, y); g.lineTo(128, y); g.stroke(); } g.restore(); }
function circles(g, list, r = 8) { g.lineWidth = 2.6; list.forEach(([x, y]) => { g.beginPath(); g.arc(x, y, r, 0, 7); g.stroke(); }); }
PAT.scenes = {
  diag: { name: 'Solo líneas ╱', draw: g => diagLines(g, 0, 0, 128, 128) },
  mixta: {
    name: 'Imagen mixta', draw: g => {
      diagLines(g, 6, 6, 52, 52);                                   // arriba-izquierda: líneas inclinadas
      circles(g, [[80, 20], [106, 22], [84, 46], [110, 48]]);       // arriba-derecha: círculos
      hLines(g, 6, 72, 52, 50);                                     // abajo-izquierda: líneas horizontales
      g.lineWidth = 2.6; g.strokeRect(72, 74, 20, 20); g.strokeRect(100, 98, 20, 20); g.strokeRect(100, 72, 18, 14); // cuadrados
      circles(g, [[82, 112]]);
    }
  },
  circulos: { name: 'Solo círculos', draw: g => { const l = []; for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) l.push([10 + x * 15.5 + (y % 2) * 7.5, 9 + y * 15.5]); circles(g, l, 6.5); } },
  horiz: { name: 'Solo líneas ─', draw: g => hLines(g, 0, 0, 128, 128) },
};

/* ---------- Kernels simulados ---------- */
function gabor(theta, P = 6, sig = 3.5, k = 13) {
  const h = k >> 1, w = new Float32Array(k * k); let m = 0;
  for (let y = 0; y < k; y++) for (let x = 0; x < k; x++) {
    const dx = x - h, dy = y - h, u = dx * Math.cos(theta) + dy * Math.sin(theta);
    w[y * k + x] = Math.cos(2 * Math.PI * u / P) * Math.exp(-(dx * dx + dy * dy) / (2 * sig * sig)); m += w[y * k + x];
  }
  m /= k * k; for (let i = 0; i < k * k; i++) w[i] -= m;
  return w;
}
/* Kernel lineal simple: conv → ReLU */
function linearUnit(w, k) {
  return {
    resp(x, S) {
      const pre = NST.conv(x, 1, S, S, w, null, 1, k), r = NST.relu(pre);
      return { r, back: dr => { const d = new Float32Array(dr.length); for (let i = 0; i < d.length; i++) if (pre[i] > 0) d[i] = dr[i]; return NST.convBack(d, 1, S, S, w, 1, k); } };
    }
  };
}
/* Detector de curvas = DOS capas, como en una CNN real:
   capa A: 8 detectores de líneas cortas (una orientación cada uno)
   capa B: para cada una de 8 orientaciones del arco, suma los detectores de línea cuya orientación
           coincide con la tangente en 7 puntos de un arco de radio R. Una recta solo enciende 2–3 puntos
           (no supera el umbral); una curva enciende los 7. */
function curveUnit(R = 8) {
  const NO = 8, kA = 9, ws1 = new Float32Array(NO * kA * kA);
  for (let o = 0; o < NO; o++) ws1.set(gabor(o * Math.PI / NO, 5, 1.8, kA), o * kA * kA);
  let nrm = 0; for (let i = 0; i < kA * kA; i++) nrm += ws1[i] ** 2; for (let i = 0; i < ws1.length; i++) ws1[i] /= Math.sqrt(nrm);
  const kB = 2 * R + 3, h = kB >> 1, ws2 = new Float32Array(8 * NO * kB * kB), alphas = [-60, -40, -20, 0, 20, 40, 60];
  for (let t = 0; t < 8; t++) {
    const th = t * Math.PI / 4, cx = R * Math.cos(th), cy = R * Math.sin(th);
    alphas.forEach(a => {
      const beta = th + Math.PI + a * Math.PI / 180, px = cx + R * Math.cos(beta), py = cy + R * Math.sin(beta);
      let o = Math.round((((beta % Math.PI) + Math.PI) % Math.PI) / (Math.PI / NO)) % NO;
      // reparto bilineal del peso en la posición (px,py)
      const x0 = Math.floor(px), y0 = Math.floor(py), fx = px - x0, fy = py - y0;
      [[0, 0, (1 - fx) * (1 - fy)], [1, 0, fx * (1 - fy)], [0, 1, (1 - fx) * fy], [1, 1, fx * fy]].forEach(([ax, ay, wv]) => {
        const X = x0 + ax + h, Y = y0 + ay + h; if (X >= 0 && Y >= 0 && X < kB && Y < kB) ws2[((t * NO + o) * kB + Y) * kB + X] += wv / alphas.length;
      });
    });
  }
  const unit = {
    NO, kA, kB, ws1, ws2, thr: 0,
    resp(x, S) {
      const N = S * S, pre1 = NST.conv(x, 1, S, S, ws1, null, NO, kA), e = NST.relu(pre1);
      // r puede ser negativo (por debajo del umbral): el FM lo recorta a 0, pero así el gradiente no muere
      const pre2 = NST.conv(e, NO, S, S, ws2, null, 8, kB), r = new Float32Array(N).fill(-1e9), ri = new Int8Array(N);
      for (let i = 0; i < N; i++) for (let t = 0; t < 8; t++) { const v = pre2[t * N + i] - unit.thr; if (v > r[i]) { r[i] = v; ri[i] = t; } }
      return {
        r, back: dr => {
          const d2 = new Float32Array(8 * N); for (let i = 0; i < N; i++) if (dr[i] !== 0) d2[ri[i] * N + i] = dr[i];
          const de = NST.convBack(d2, NO, S, S, ws2, 8, kB); for (let i = 0; i < de.length; i++) if (pre1[i] <= 0) de[i] = 0;
          return NST.convBack(de, 1, S, S, ws1, NO, kA);
        }
      };
    }
  };
  // umbral: algo por encima de lo que produce una recta (medido con una línea larga)
  const S = 64, line = PAT.render(g => { g.lineWidth = 2.6; g.beginPath(); g.moveTo(10, 118); g.lineTo(118, 10); g.stroke(); g.beginPath(); g.moveTo(0, 30); g.lineTo(128, 30); g.stroke(); }, S);
  const circ = PAT.render(g => { g.lineWidth = 2.6; g.beginPath(); g.arc(64, 64, R * 2, 0, 7); g.stroke(); }, S); // en S=64 el radio queda en R
  const mx = a => a.reduce((m, v) => Math.max(m, v), 0);
  const lineMax = mx(unit.resp(line, S).r), circMax = mx(unit.resp(circ, S).r);
  unit.thr = lineMax + .25 * (circMax - lineMax);
  return unit;
}
PAT.kernels = {
  diag: { name: 'Kernel de líneas ╱', unit: linearUnit(gabor(Math.PI / 4), 13), show: [gabor(Math.PI / 4)], k: 13, ideal: 'diag' },
  curva: { name: 'Kernel de curvas', unit: curveUnit(), ideal: 'circulos' },
  horiz: { name: 'Kernel de líneas ─', unit: linearUnit(gabor(Math.PI / 2), 13), show: [gabor(Math.PI / 2)], k: 13, ideal: 'horiz' },
};

/* ---------- Feature map: kernel → ReLU → max‑pool 5×5 → /ref → recorte a [0,1] ---------- */
const POOL = 2; // radio del max-pool (ventana 5×5, paso 1)
PAT.forward = function (x, S, K) {
  const N = S * S, u = K.unit.resp(x, S), r = u.r;
  const p = new Float32Array(N), pi = new Int32Array(N);
  for (let y = 0; y < S; y++) for (let x0 = 0; x0 < S; x0++) {
    let b = -Infinity, bi = y * S + x0;
    for (let dy = -POOL; dy <= POOL; dy++) { const yy = y + dy; if (yy < 0 || yy >= S) continue; for (let dx = -POOL; dx <= POOL; dx++) { const xx = x0 + dx; if (xx < 0 || xx >= S) continue; const v = r[yy * S + xx]; if (v > b) { b = v; bi = yy * S + xx; } } }
    p[y * S + x0] = b; pi[y * S + x0] = bi;
  }
  const fm = new Float32Array(N); for (let i = 0; i < N; i++) fm[i] = Math.max(0, Math.min(1, p[i] / K.ref));
  return { u, p, pi, fm };
};
/* Gradiente de L = 1 − mean(FM) respecto a la imagen */
PAT.backward = function (st, S, K) {
  const N = S * S, dr = new Float32Array(N);
  // por debajo de 0 se usa una pendiente pequeña (0.1), como una "leaky ReLU", para que la imagen pueda empezar a cambiar
  for (let i = 0; i < N; i++) if (st.p[i] < K.ref && st.p[i] > -1e8) dr[st.pi[i]] += -(st.p[i] > 0 ? 1 : .1) / (N * K.ref);
  return st.u.back(dr);
};
PAT.mean = a => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i]; return s / a.length; };
// Referencia de normalización: la respuesta típica (percentil 90) del kernel ante su patrón ideal
Object.values(PAT.kernels).forEach(K => {
  K.ref = 1; const st = PAT.forward(PAT.render(PAT.scenes[K.ideal].draw, 128), 128, K);
  const v = Array.from(st.p).sort((a, b) => a - b); K.ref = v[Math.floor(v.length * .9)] || 1;
});

/* Dibujo del kernel de curvas: cada arco como segmentos con la orientación que busca */
function drawCurveKernel(cv, unit, t) {
  const kB = unit.kB, sc = 4; cv.width = cv.height = kB * sc; const g = cv.getContext('2d');
  g.fillStyle = '#f2f2f2'; g.fillRect(0, 0, cv.width, cv.height);
  for (let o = 0; o < unit.NO; o++) for (let y = 0; y < kB; y++) for (let x = 0; x < kB; x++) {
    const w = unit.ws2[((t * unit.NO + o) * kB + y) * kB + x]; if (w < .02) continue;
    const phi = o * Math.PI / unit.NO + Math.PI / 2, cx = (x + .5) * sc, cy = (y + .5) * sc, L = 5;
    g.strokeStyle = `rgba(224,72,62,${Math.min(1, w * 9)})`; g.lineWidth = 2;
    g.beginPath(); g.moveTo(cx - L * Math.cos(phi), cy - L * Math.sin(phi)); g.lineTo(cx + L * Math.cos(phi), cy + L * Math.sin(phi)); g.stroke();
  }
}
function drawKernel(cv, w, k) {
  cv.width = cv.height = k; let m = 0; for (const v of w) m = Math.max(m, Math.abs(v));
  const g = cv.getContext('2d'), id = g.createImageData(k, k);
  for (let i = 0; i < k * k; i++) { const c = NST.diverging(w[i] / m); id.data.set([c[0], c[1], c[2], 255], i * 4); }
  g.putImageData(id, 0, 0);
}
function drawOverlay(cv, img, fm, S) {
  cv.width = cv.height = S; const g = cv.getContext('2d'), id = g.createImageData(S, S);
  for (let i = 0; i < S * S; i++) { const b = img[i] * 70, v = fm[i]; id.data.set([b + v * 255, b + v * 190, b + v * 30, 255], i * 4); }
  g.putImageData(id, 0, 0);
}

/* =========================================================================
   Capítulo 4 — kernels especializados
   ========================================================================= */
(function chapterKernels() {
  const S = 128, inCv = $('#kxIn'), fmCv = $('#kxFm'), ovCv = $('#kxOv'), kBox = $('#kxKernel'), scanLine = $('#kxScan');
  let scene = 'diag', kern = 'diag', anim = null;
  const GUIDE = [
    ['diag', 'diag', '<b>Paso 1.</b> Una imagen hecha <b>solo de líneas inclinadas ╱</b> pasa por un kernel especializado en ese patrón. Como el patrón está en todas partes, el feature map sale <b>casi todo blanco</b>: el kernel “encaja” en todas las posiciones.'],
    ['mixta', 'diag', '<b>Paso 2.</b> Ahora una imagen con <b>varios patrones</b> (líneas inclinadas, líneas horizontales, círculos y cuadrados). El mismo kernel ╱ solo se enciende en la zona de líneas inclinadas; el resto queda casi negro. Fíjate en los círculos: se activan un poco justo donde su borde es inclinado.'],
    ['mixta', 'curva', '<b>Paso 3.</b> La misma imagen mixta pasa por un kernel de <b>curvas</b>. Ahora se encienden los <b>círculos</b> (y un poco las esquinas) mientras que las líneas rectas, inclinadas u horizontales, se apagan.'],
  ];
  const sceneSeg = $('#kxScene'), kSeg = $('#kxKern');
  Object.entries(PAT.scenes).forEach(([k, s]) => { const b = el('button', k === scene ? 'on' : '', sceneSeg, s.name); b.dataset.k = k; });
  Object.entries(PAT.kernels).forEach(([k, s]) => { const b = el('button', k === kern ? 'on' : '', kSeg, s.name); b.dataset.k = k; });
  const mark = (seg, k) => seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.k === k));
  segInit(sceneSeg, d => { scene = d.k; setGuide(-1); run(); });
  segInit(kSeg, d => { kern = d.k; setGuide(-1); run(); });
  const gBtns = $$('#kxGuide button');
  function setGuide(i) {
    gBtns.forEach((b, k) => b.classList.toggle('on', k === i));
    $('#kxText').innerHTML = i >= 0 ? GUIDE[i][2] : 'Exploración libre: combina cualquier imagen con cualquier kernel.';
  }
  gBtns.forEach((b, i) => b.addEventListener('click', () => { [scene, kern] = GUIDE[i]; mark(sceneSeg, scene); mark(kSeg, kern); setGuide(i); run(); }));

  function run() {
    cancelAnimationFrame(anim);
    const img = PAT.render(PAT.scenes[scene].draw, S), K = PAT.kernels[kern], st = PAT.forward(img, S, K), mean = PAT.mean(st.fm);
    NST.drawMap(inCv, img, S, S, 'gray', 1);
    kBox.innerHTML = '';
    if (K.show) K.show.forEach(w => { const c = el('canvas', '', kBox); drawKernel(c, w, K.k); });
    else for (let t = 0; t < 8; t++) { const c = el('canvas', '', kBox); drawCurveKernel(c, K.unit, t); }
    $('#kxKName').textContent = K.show ? K.name : `${K.name}: 8 arcos hechos de detectores de líneas cortas (2 capas)`;
    let row = 0; const t0 = performance.now();
    const tick = now => {
      row = Math.min(S, Math.floor((now - t0) / 1100 * S));
      const part = st.fm.slice(), ov = st.fm.slice();
      for (let i = row * S; i < S * S; i++) part[i] = ov[i] = 0;
      NST.drawMap(fmCv, part, S, S, 'gray', 1); drawOverlay(ovCv, img, ov, S);
      scanLine.style.top = (row / S * 100) + '%'; scanLine.style.opacity = row < S ? 1 : 0;
      const m = PAT.mean(part); $('#kxMeanBar').style.width = (m * 100) + '%'; $('#kxMean').textContent = (m * 100).toFixed(0) + '%';
      if (row < S) anim = requestAnimationFrame(tick); else { $('#kxMean').textContent = (mean * 100).toFixed(0) + '%'; $('#kxMeanBar').style.width = (mean * 100) + '%'; }
    };
    anim = requestAnimationFrame(tick);
  }
  setGuide(0);
  PAT.kxInit = run;
})();

/* =========================================================================
   Capítulo 7 — la imagen que maximiza un feature map (Adam, loss = 1 − media)
   ========================================================================= */
(function chapterMaximize() {
  const S = 64, N = S * S, imgCv = $('#mxImg'), fmCv = $('#mxFm'), idealCv = $('#mxIdeal'), chart = $('#mxChart');
  let kern = 'diag', x = null, m = null, v = null, t = 0, hist = [], running = false;
  const seg = $('#mxKern');
  Object.entries(PAT.kernels).forEach(([k, s]) => { const b = el('button', k === kern ? 'on' : '', seg, s.name); b.dataset.k = k; });
  segInit(seg, d => { kern = d.k; reset(); });
  const lrIn = $('#mxLr'); lrIn.addEventListener('input', () => $('#mxLrOut').textContent = (+lrIn.value / 1000).toFixed(3));
  function reset() {
    stop(); const r = NST.rng((Math.random() * 1e6) | 0);
    x = new Float32Array(N); for (let i = 0; i < N; i++) x[i] = r(); // ruido uniforme en [0,1]
    m = new Float32Array(N); v = new Float32Array(N); t = 0; hist = [];
    NST.drawMap(idealCv, PAT.render(PAT.scenes[PAT.kernels[kern].ideal].draw, S), S, S, 'gray', 1);
    // el kernel K que se aplica (fijo durante toda la optimización)
    const K = PAT.kernels[kern], box = $('#mxKernelBox'); box.innerHTML = '';
    if (K.show) K.show.forEach(w => drawKernel(el('canvas', '', box), w, K.k));
    else for (let t = 0; t < 8; t++) drawCurveKernel(el('canvas', '', box), K.unit, t);
    $('#mxKName').textContent = K.show ? `${K.name} (fijo)` : `${K.name}: 8 arcos (fijo)`;
    draw(PAT.forward(x, S, PAT.kernels[kern]));
  }
  function draw(st) {
    NST.drawMap(imgCv, x, S, S, 'gray', 1); NST.drawMap(fmCv, st.fm, S, S, 'gray', 1);
    const mean = PAT.mean(st.fm), loss = 1 - mean;
    $('#mxMean').textContent = mean.toFixed(3); $('#mxLoss').textContent = loss.toFixed(3); $('#mxIter').textContent = t;
    $('#mxMeanBar').style.width = (mean * 100) + '%';
    lineChart(chart, [hist], { colors: [NST.css('--accent2')] });
  }
  function step() {
    const K = PAT.kernels[kern], st = PAT.forward(x, S, K); hist.push(1 - PAT.mean(st.fm));
    const g = PAT.backward(st, S, K), lr = +lrIn.value / 1000;
    t++; const b1 = .9, b2 = .999, c1 = 1 - b1 ** t, c2 = 1 - b2 ** t;
    for (let i = 0; i < N; i++) {
      m[i] = b1 * m[i] + (1 - b1) * g[i]; v[i] = b2 * v[i] + (1 - b2) * g[i] * g[i];
      x[i] = Math.max(0, Math.min(1, x[i] - lr * (m[i] / c1) / (Math.sqrt(v[i] / c2) + 1e-8)));
    }
    return st;
  }
  function frame() {
    if (!running) return;
    const t0 = performance.now(); let st;
    do st = step(); while (performance.now() - t0 < 25);
    draw(st); const ph = Math.floor(performance.now() / 200) % 4; $$('#mxPipe span').forEach((s, i) => s.classList.toggle('on', i === ph));
    if (t >= 400 || hist[hist.length - 1] < .02) { stop(); return; }
    requestAnimationFrame(frame);
  }
  function stop() { running = false; $('#mxRun').textContent = '▶ Optimizar con Adam'; $('#mxRun').classList.remove('running'); $$('#mxPipe span').forEach(s => s.classList.remove('on')); }
  $('#mxRun').addEventListener('click', () => {
    if (running) { stop(); return; }
    if (t >= 400) reset();
    running = true; $('#mxRun').textContent = '❚❚ Pausa'; $('#mxRun').classList.add('running'); requestAnimationFrame(frame);
  });
  $('#mxReset').addEventListener('click', reset);
  PAT.mxInit = reset;
})();

/* =========================================================================
   Capítulo 10 — extraer el estilo de una imagen
   ========================================================================= */
(function chapterExtract() {
  const net = NST.net, S = 64, N3 = 3 * S * S;
  const st = { src: NST.getImage('remolinos'), mode: null, x: null, m: null, v: null, t: 0, hist: [], sel: [], refs: [], A: [], norm: [], A0: null, n0: 1, styleLoss1: 0 };
  const pick = $('#exPick');
  NST.styleList.forEach(([k, n], i) => { const b = el('button', i === 0 ? 'on' : '', pick, n); b.dataset.k = k; });
  segInit(pick, d => { st.src = NST.getImage(d.k); prepare(); });
  $('#exUp').addEventListener('change', async e => { const f = e.target.files[0]; if (!f) return; st.src = await NST.loadFile(f); pick.querySelectorAll('button').forEach(b => b.classList.remove('on')); prepare(); });
  const colorFeats = (x) => { const N = S * S, F = new Float32Array(4 * N); for (let i = 0; i < 3 * N; i++) F[i] = x[i] - .5; F.fill(1, 3 * N); return F; };

  function prepare() {
    stopAll();
    NST.drawSrc($('#exStyle'), st.src);
    const crop = document.createElement('canvas'); crop.width = crop.height = 256;
    crop.getContext('2d').drawImage(st.src, 64, 64, 128, 128, 0, 0, 256, 256); // centro ampliado ×2
    const t = NST.toTensor(crop, S), s = net.forward(t, S);
    // "kernels de estilo": los canales de las capas 1 y 2 que más se activan con esta imagen
    st.sel = []; st.refs = [];
    const box = $('#exMaps'); box.innerHTML = '';
    [0, 1].forEach(l => {
      const C = net.C[l], sz = s.sizes[l], N = sz * sz, a = s.a[l], means = [];
      for (let c = 0; c < C; c++) { let mm = 0, mx = 0; for (let i = 0; i < N; i++) { mm += a[c * N + i]; mx = Math.max(mx, a[c * N + i]); } means.push([mm / N, c, mx]); }
      means.sort((p, q) => q[0] - p[0]).slice(0, 4).forEach(([, c, mx], i) => {
        st.sel.push([l, c]); st.refs.push(mx * .7 + 1e-6);
        const f = el('figure', '', box), cv = el('canvas', '', f); NST.drawMap(cv, a, sz, sz, 'gray', mx * .7, c * N);
        el('figcaption', '', f, `capa ${l + 1} · k${c}`); f.style.animationDelay = (i * .06 + l * .25) + 's';
      });
    });
    st.styleLoss1 = loss1(s);
    $('#exRefLoss').textContent = st.styleLoss1.toFixed(3);
    st.A = []; st.norm = [];
    for (let l = 0; l < 3; l++) { const sz = s.sizes[l], G = NST.gram(s.a[l], net.C[l], sz * sz); st.A.push(G); st.norm.push(G.reduce((a, v) => a + v * v, 0) / G.length + 1e-12); }
    const F0 = colorFeats(t); st.A0 = NST.gram(F0, 4, S * S); st.n0 = st.A0.reduce((a, v) => a + v * v, 0) / 16 / 6;
    ['#exOut1', '#exOut2'].forEach(id => { const g = $(id).getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, 999, 999); });
    $('#exL1').textContent = '—'; $('#exL2').textContent = '—';
  }
  /* Intento 1: L = 1 − promedio de los feature maps de estilo (normalizados a [0,1]) */
  function loss1(s) {
    let L = 0;
    st.sel.forEach(([l, c], k) => { const sz = s.sizes[l], N = sz * sz, a = s.a[l]; let mm = 0; for (let i = 0; i < N; i++) mm += Math.min(1, a[c * N + i] / st.refs[k]); L += mm / N; });
    return 1 - L / st.sel.length;
  }
  function grad1(s) {
    const dA = [null, null, null];
    st.sel.forEach(([l, c], k) => {
      const sz = s.sizes[l], N = sz * sz, a = s.a[l]; if (!dA[l]) dA[l] = new Float32Array(net.C[l] * N);
      for (let i = 0; i < N; i++) if (a[c * N + i] < st.refs[k]) dA[l][c * N + i] = -1 / (st.sel.length * N * st.refs[k]);
    });
    return net.backward(s, dA);
  }
  /* Intento 2: igualar las matrices de Gram (cuánto y con quién se activa cada kernel) */
  function grad2(s, x) {
    const dA = [null, null, null]; let L = 0;
    for (let l = 0; l < 3; l++) {
      const C = net.C[l], sz = s.sizes[l], N = sz * sz, F = s.a[l], G = NST.gram(F, C, N), A = st.A[l], dF = new Float32Array(C * N);
      for (let i = 0; i < C; i++) for (let j = 0; j < C; j++) {
        const d = G[i * C + j] - A[i * C + j]; L += d * d / (C * C * st.norm[l]) / 4;
        const k = 2 * d / (C * C * st.norm[l]) / 4 * 2 / N; if (k === 0) continue;
        for (let q = 0; q < N; q++) dF[i * N + q] += k * F[j * N + q];
      }
      dA[l] = dF;
    }
    const g = net.backward(s, dA), N = S * S, F0 = colorFeats(x), G0 = NST.gram(F0, 4, N);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      const d = G0[i * 4 + j] - st.A0[i * 4 + j]; L += d * d / (16 * st.n0) / 4;
      if (i < 3) { const k = 2 * d / (16 * st.n0) / 4 * 2 / N; for (let q = 0; q < N; q++) g[i * N + q] += k * F0[j * N + q]; }
    }
    // suavidad (variación total) para evitar ruido de alta frecuencia
    const kt = .05 * 2 / (S * S);
    for (let c = 0; c < 3; c++) for (let y = 0; y < S; y++) for (let xx = 0; xx < S; xx++) {
      const i = c * S * S + y * S + xx;
      if (xx < S - 1) { const d = x[i + 1] - x[i]; g[i] -= kt * d; g[i + 1] += kt * d; }
      if (y < S - 1) { const d = x[i + S] - x[i]; g[i] -= kt * d; g[i + S] += kt * d; }
    }
    return [g, L];
  }
  function start(mode) {
    stopAll(); st.mode = mode; const r = NST.rng((Math.random() * 1e6) | 0);
    st.x = new Float32Array(N3); for (let i = 0; i < N3; i++) st.x[i] = r();
    st.m = new Float32Array(N3); st.v = new Float32Array(N3); st.t = 0; st.hist = [];
    const b = $(mode === 1 ? '#exRun1' : '#exRun2'); b.classList.add('running'); b.textContent = '❚❚ Detener';
    requestAnimationFrame(frame);
  }
  function stopAll() {
    st.mode = null;
    $('#exRun1').classList.remove('running'); $('#exRun1').textContent = '▶ Intento 1: maximizar';
    $('#exRun2').classList.remove('running'); $('#exRun2').textContent = '▶ Intento 2: igualar Gram';
  }
  function frame() {
    if (!st.mode) return;
    const t0 = performance.now(), lr = .03;
    do {
      const s = net.forward(st.x, S, st.mode === 1 ? 1 : 2);
      let g, L;
      if (st.mode === 1) { L = loss1(s); g = grad1(s); } else [g, L] = grad2(s, st.x);
      st.hist.push(L); st.t++;
      const c1 = 1 - .9 ** st.t, c2 = 1 - .999 ** st.t;
      for (let i = 0; i < N3; i++) {
        st.m[i] = .9 * st.m[i] + .1 * g[i]; st.v[i] = .999 * st.v[i] + .001 * g[i] * g[i];
        st.x[i] = Math.max(0, Math.min(1, st.x[i] - lr * (st.m[i] / c1) / (Math.sqrt(st.v[i] / c2) + 1e-8)));
      }
    } while (performance.now() - t0 < 35);
    const out = st.mode === 1 ? '#exOut1' : '#exOut2';
    NST.drawRGB($(out), st.x, S, false);
    $(st.mode === 1 ? '#exL1' : '#exL2').textContent = `iter ${st.t} · loss ${st.hist[st.hist.length - 1].toFixed(3)}`;
    lineChart($('#exChart'), [st.hist], { log: st.mode === 2, colors: [st.mode === 1 ? NST.css('--accent2') : NST.css('--style')] });
    if (st.t >= (st.mode === 1 ? 250 : 600)) { stopAll(); return; }
    requestAnimationFrame(frame);
  }
  $('#exRun1').addEventListener('click', () => st.mode === 1 ? stopAll() : start(1));
  $('#exRun2').addEventListener('click', () => st.mode === 2 ? stopAll() : start(2));
  PAT.exInit = prepare;
})();

/* =========================================================================
   Capítulo 6 — mapeo previo: en qué capas de VGG‑19 se especializa cada tipo de patrón
   (porcentajes ilustrativos / simulados)
   ========================================================================= */
(function chapterMap() {
  const LAYERS = ['conv1_1', 'conv2_1', 'conv3_1', 'conv4_1', 'conv4_2', 'conv5_1'];
  const DESC = {
    conv1_1: 'Primera capa: mira trozos de 3×3 píxeles. Casi todo es color, luz y bordes muy finos.',
    conv2_1: 'Combina los kernels de la capa 1: aparecen texturas finas y trazos.',
    conv3_1: 'Texturas y patrones repetidos a escala media: el “trazo” de un cuadro.',
    conv4_1: 'Patrones grandes y primeras formas.',
    conv4_2: 'Domina la estructura: formas, contornos y partes de objetos, sin importar el color ni la textura.',
    conv5_1: 'Campo receptivo enorme: patrones muy grandes mezclados con partes de objetos.',
  };
  const CATS = [
    { n: 'Color', s: true, c: '#e0483e' }, { n: 'Iluminación / contraste', s: true, c: '#e07a1f' },
    { n: 'Textura', s: true, c: '#d9a400' }, { n: 'Patrones repetidos', s: true, c: '#c2549a' },
    { n: 'Bordes y líneas', s: false, c: '#2a9d8f' }, { n: 'Formas y estructura', s: false, c: '#1f7a5a' }, { n: 'Partes y objetos', s: false, c: '#2f6fe4' },
  ];
  const DATA = [ // filas = categorías, columnas = capas (cada columna suma 100)
    [45, 25, 12, 6, 3, 4], [25, 15, 8, 4, 2, 3], [5, 25, 30, 22, 10, 18], [0, 10, 25, 28, 12, 25],
    [25, 25, 15, 12, 20, 8], [0, 0, 8, 16, 33, 22], [0, 0, 2, 12, 20, 20],
  ];
  const styleShare = j => CATS.reduce((s, c, i) => s + (c.s ? DATA[i][j] : 0), 0);

  /* Miniaturas: ejemplo de lo que enciende a un kernel de cada tipo */
  const THUMB = [
    g => { ['#e63946', '#2a9d8f', '#f1c453', '#3d6fb6'].forEach((c, i) => { g.fillStyle = c; g.fillRect((i % 2) * 20, (i >> 1) * 20, 20, 20); }); },
    g => { const r = g.createRadialGradient(14, 12, 2, 20, 20, 30); r.addColorStop(0, '#fff'); r.addColorStop(1, '#222'); g.fillStyle = r; g.fillRect(0, 0, 40, 40); },
    g => { const r = NST.rng(5); for (let y = 0; y < 40; y += 2) for (let x = 0; x < 40; x += 2) { const v = 90 + r() * 120; g.fillStyle = `rgb(${v},${v * .8},${v * .55})`; g.fillRect(x, y, 2, 2); } },
    g => { g.fillStyle = '#1d3557'; g.fillRect(0, 0, 40, 40); g.fillStyle = '#f4a261'; for (let y = 4; y < 40; y += 9) for (let x = 4; x < 40; x += 9) { g.beginPath(); g.arc(x, y, 3, 0, 7); g.fill(); } },
    g => { g.fillStyle = '#ddd'; g.fillRect(0, 0, 40, 40); g.fillStyle = '#222'; g.beginPath(); g.moveTo(0, 40); g.lineTo(40, 0); g.lineTo(40, 40); g.fill(); },
    g => { g.fillStyle = '#eef'; g.fillRect(0, 0, 40, 40); g.strokeStyle = '#222'; g.lineWidth = 2.5; g.beginPath(); g.arc(14, 15, 9, 0, 7); g.stroke(); g.strokeRect(20, 20, 15, 14); },
    g => { g.fillStyle = '#f6d7b0'; g.fillRect(0, 0, 40, 40); g.fillStyle = '#fff'; g.beginPath(); g.ellipse(20, 20, 15, 9, 0, 0, 7); g.fill(); g.fillStyle = '#5a3d1e'; g.beginPath(); g.arc(20, 20, 6, 0, 7); g.fill(); g.fillStyle = '#000'; g.beginPath(); g.arc(20, 20, 3, 0, 7); g.fill(); },
  ];
  const thumb = i => { const c = document.createElement('canvas'); c.width = c.height = 40; THUMB[i](c.getContext('2d')); return c; };
  const hexA = (h, a) => `rgba(${parseInt(h.substr(1, 2), 16)},${parseInt(h.substr(3, 2), 16)},${parseInt(h.substr(5, 2), 16)},${a})`;

  /* Tabla */
  const tbl = $('#mapTable'); let mapped = false;
  const head = el('tr', '', tbl); el('th', '', head, '');
  const colTh = LAYERS.map((L, j) => { const th = el('th', 'col', head, L); th.addEventListener('click', () => mapped && select(j)); return th; });
  const cells = CATS.map((c, i) => {
    const tr = el('tr', '', tbl); el('th', 'row', tr, `<i style="background:${c.c}"></i>${c.n}`);
    return LAYERS.map((L, j) => { const td = el('td', '', tr, DATA[i][j] + '%'); td.addEventListener('click', () => mapped && select(j)); return td; });
  });
  const sumTr = el('tr', 'sum', tbl); el('th', 'row', sumTr, 'Tendencia');
  const sumTd = LAYERS.map(() => el('td', '', sumTr, ''));
  function fillCol(j) {
    CATS.forEach((c, i) => { const td = cells[i][j]; td.style.background = hexA(c.c, .12 + DATA[i][j] / 50); td.classList.add('on'); });
    const s = styleShare(j), est = s >= 50;
    sumTd[j].innerHTML = `<div class="split"><b style="width:${s}%;background:var(--style)"></b><b style="width:${100 - s}%;background:var(--content)"></b></div>
      ${s}% estilo<br><span class="verdict" style="background:var(${est ? '--style' : '--content'})">${est ? 'estilo' : 'contenido'}</span>`;
  }
  function clearAll() { cells.flat().forEach(td => { td.style.background = ''; td.classList.remove('on', 'sel'); }); sumTd.forEach(td => td.innerHTML = ''); colTh.forEach(t => t.classList.remove('sel')); }

  /* Detalle de una capa */
  function select(j) {
    colTh.forEach((t, k) => t.classList.toggle('sel', k === j));
    cells.forEach(r => r.forEach((td, k) => td.classList.toggle('sel', k === j)));
    const d = $('#mapDetail'), s = styleShare(j);
    d.innerHTML = `<h4>${LAYERS[j]} · ${s >= 50 ? '<span class="tag-s">capa de estilo</span>' : '<span class="tag-c">capa de contenido</span>'}</h4><p class="hint">${DESC[LAYERS[j]]}</p><div class="bars"></div>`;
    const bars = d.querySelector('.bars');
    CATS.map((c, i) => [DATA[i][j], i]).sort((a, b) => b[0] - a[0]).forEach(([v, i]) => {
      const row = el('div', 'brow', bars); row.appendChild(thumb(i));
      const b = el('div', 'b', row), fill = el('i', '', b); fill.style.background = CATS[i].c; fill.style.width = '0';
      el('span', '', row, v + '%'); el('div', 'lbl', row, CATS[i].n);
      requestAnimationFrame(() => requestAnimationFrame(() => fill.style.width = v * 2 + '%'));
    });
  }

  /* Animación del mapeo */
  const steps = $$('#mapSteps li'), feed = $('#mapFeed'); let busy = false;
  const net = el('div', 'net', feed, 'VGG‑19 congelada');
  const setStep = i => steps.forEach((s, k) => s.classList.toggle('on', k === i));
  async function run() {
    if (busy) return; busy = true; mapped = false; $('#mapRun').disabled = true; clearAll();
    $('#mapDetail').innerHTML = '<p class="hint">Analizando la red…</p>';
    setStep(0); await sleep(900); setStep(1);
    const names = [...NST.contentList, ...NST.styleList].map(([k]) => k), total = 10000, dur = 3600, t0 = performance.now();
    let spawned = 0, col = 0;
    await new Promise(res => {
      const tick = now => {
        const k = Math.min(1, (now - t0) / dur);
        $('#mapCount').textContent = Math.round(k * total).toLocaleString('es');
        $('#mapBar').style.width = k * 100 + '%';
        if (now - t0 > spawned * 260 && k < .92) { // una miniatura entra en la red
          const c = document.createElement('canvas'); c.width = c.height = 40; NST.drawSrc(c, NST.getImage(names[spawned % names.length]));
          c.style.left = '-44px'; c.style.transition = 'left 1.1s linear, opacity .3s'; feed.insertBefore(c, net);
          requestAnimationFrame(() => requestAnimationFrame(() => c.style.left = (feed.clientWidth - 90) + 'px'));
          setTimeout(() => { c.style.opacity = 0; setTimeout(() => feed.removeChild(c), 300); }, 1100); spawned++;
        }
        if (k > .3) setStep(2);
        while (col < LAYERS.length && k > .3 + col * .11) { fillCol(col); col++; }
        if (k < 1) requestAnimationFrame(tick); else res();
      };
      requestAnimationFrame(tick);
    });
    while (col < LAYERS.length) fillCol(col++);
    setStep(3); mapped = true; select(4);
    busy = false; $('#mapRun').disabled = false; $('#mapRun').textContent = '↺ Repetir el mapeo';
  }
  $('#mapRun').addEventListener('click', run);
  $('#mapDetail').innerHTML = '<p class="hint">Pulsa <b>Mapear la red</b> para construir el mapa de tendencias.</p>';
  new IntersectionObserver((en, ob) => { if (en[0].isIntersecting) { ob.disconnect(); run(); } }, { threshold: .35 }).observe(tbl);
})();

/* =========================================================================
   Capítulo 9 — kernels de forma (contenido) + kernels de estilo → fusión
   ========================================================================= */
(function chapterFusion() {
  const net = NST.net, S = 96;
  let content = NST.getImage('paisaje'), style = NST.getImage('remolinos');
  function picker(root, list, set) {
    list.forEach(([k, n], i) => { const b = el('button', i === 0 ? 'on' : '', root, n); b.dataset.k = k; });
    segInit(root, d => { set(NST.getImage(d.k)); update(); });
  }
  picker($('#fuContentPick'), NST.contentList, v => content = v);
  picker($('#fuStylePick'), NST.styleList, v => style = v);
  /* Muestra los k canales con más "respuesta" de una capa (ordenados por varianza espacial o por media) */
  function topMaps(box, st, l, k, byVar, delay) {
    box.innerHTML = '';
    const C = net.C[l], s = st.sizes[l], N = s * s, a = st.a[l], score = [];
    for (let c = 0; c < C; c++) {
      let m = 0, q = 0; for (let i = 0; i < N; i++) { m += a[c * N + i]; q += a[c * N + i] ** 2; }
      m /= N; score.push([byVar ? q / N - m * m : m, c]);
    }
    score.sort((p, q) => q[0] - p[0]).slice(0, k).forEach(([, c], i) => {
      const cv = el('canvas', '', box); NST.drawMap(cv, a, s, s, 'gray', null, c * N);
      cv.style.animation = `pop .5s ${delay + i * .08}s ease both`;
    });
  }
  function update() {
    NST.drawSrc($('#fuContent'), content); NST.drawSrc($('#fuStyle'), style);
    const sc = net.forward(NST.toTensor(content, S), S), ss = net.forward(NST.toTensor(style, S), S);
    topMaps($('#fuCMaps'), sc, 1, 4, true, 0);    // forma: capa más profunda, los que más varían de un sitio a otro
    topMaps($('#fuSMaps'), ss, 0, 4, false, .3);  // estilo: capa superficial, los que más se encienden
    const G = NST.gram(ss.a[0], 16, S * S), rc = $('#fuRecipe');
    NST.drawMap(rc, G.map(v => Math.sqrt(Math.max(0, v))), 16, 16, 'magma');
  }
  update();
})();
