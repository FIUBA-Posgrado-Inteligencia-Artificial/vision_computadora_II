/* =========================================================================
   sections.js — capítulos 1, 2, 3, 4, 5 y 7
   ========================================================================= */
'use strict';

const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
function el(tag, cls, parent, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; if (parent) parent.appendChild(e); return e; }
function segInit(root, onChange) {
  root.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || !root.contains(b)) return;
    root.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); onChange(b.dataset, b);
  });
}
function rgbStr(c) { return `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`; }
function textOn(c) { return (c[0] * .299 + c[1] * .587 + c[2] * .114) > 140 ? '#111' : '#fff'; }
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* Filtros 3×3 de ejemplo */
const KERNELS = {
  'Borde vertical': [-1, 0, 1, -2, 0, 2, -1, 0, 1],
  'Borde horizontal': [-1, -2, -1, 0, 0, 0, 1, 2, 1],
  'Borde diagonal': [0, 1, 2, -1, 0, 1, -2, -1, 0],
  'Línea vertical': [-1, 2, -1, -1, 2, -1, -1, 2, -1],
  'Línea horizontal': [-1, -1, -1, 2, 2, 2, -1, -1, -1],
  'Línea ╲': [2, -1, -1, -1, 2, -1, -1, -1, 2],
  'Línea ╱': [-1, -1, 2, -1, 2, -1, 2, -1, -1],
  'Esquina ┌': [-1, -1, -1, -1, 1, 1, -1, 1, 1],
  'Punto aislado': [-1, -1, -1, -1, 8, -1, -1, -1, -1],
};
const fmt = v => Math.abs(v - Math.round(v)) < 1e-6 ? String(Math.round(v)) : v.toFixed(2).replace(/^0\./, '.').replace(/^-0\./, '-.');

/* =========================================================================
   Capítulo 1 — píxeles
   ========================================================================= */
(function chapter1() {
  const picker = $('#imgPicker');
  [...NST.contentList, ...NST.styleList].forEach(([k, n], i) => { const b = el('button', i === 0 ? 'on' : '', picker, n); b.dataset.k = k; });
  segInit(picker, d => NST.setWork(d.k));
  $('#imgUpload').addEventListener('change', async e => {
    const f = e.target.files[0]; if (!f) return;
    const c = await NST.loadFile(f); picker.querySelectorAll('button').forEach(b => b.classList.remove('on'));
    NST.setWork('subida', c);
  });

  const stack = $('#rgbStack');
  $('#splitBtn').addEventListener('click', () => {
    stack.classList.toggle('split');
    $('#splitBtn').textContent = stack.classList.contains('split') ? 'Combinar canales' : 'Separar canales R, G, B';
  });

  const pix = $('#pixImg'), table = $('#pixTable'), S = 48;
  let tensor = null, chan = 0, last = [20, 20];
  for (let i = 0; i < 36; i++) el('div', '', table);
  segInit($('#pixChan'), d => { chan = +d.c; drawPix(); showWin(...last); });

  function drawStack() {
    const t = NST.toTensor(NST.work.src, 128), N = 128 * 128;
    stack.querySelectorAll('canvas').forEach((cv, li) => {
      const g = cv.getContext('2d'), id = g.createImageData(128, 128), d = id.data;
      for (let i = 0; i < N; i++) {
        for (let c = 0; c < 3; c++) d[i * 4 + c] = (li === 3 || li === c) ? t[c * N + i] * 255 : 0;
        d[i * 4 + 3] = 255;
      }
      g.putImageData(id, 0, 0);
    });
  }
  function val(i) { const N = S * S; return chan < 3 ? tensor[chan * N + i] : .299 * tensor[i] + .587 * tensor[N + i] + .114 * tensor[2 * N + i]; }
  function drawPix() {
    tensor = NST.toTensor(NST.work.src, S); NST.drawRGB(pix, tensor, S);
  }
  function showWin(x0, y0) {
    last = [x0, y0];
    drawPix();
    const g = pix.getContext('2d'); g.strokeStyle = '#fff'; g.lineWidth = .6; g.strokeRect(x0 + .3, y0 + .3, 5.4, 5.4);
    g.strokeStyle = '#000'; g.lineWidth = .3; g.strokeRect(x0 - .1, y0 - .1, 6.2, 6.2);
    const cells = table.children;
    for (let j = 0; j < 6; j++) for (let i = 0; i < 6; i++) {
      const v = val((y0 + j) * S + x0 + i), c = cells[j * 6 + i];
      const col = chan === 0 ? [v * 255, 0, 0] : chan === 1 ? [0, v * 255, 0] : chan === 2 ? [0, 0, v * 255] : [v * 255, v * 255, v * 255];
      c.textContent = v.toFixed(2); c.style.background = rgbStr(col); c.style.color = textOn(col.map(x => chan === 3 ? x : x * 1.6));
    }
  }
  pix.addEventListener('mousemove', e => {
    const r = pix.getBoundingClientRect();
    const x = Math.max(0, Math.min(S - 6, Math.floor((e.clientX - r.left) / r.width * S) - 3)), y = Math.max(0, Math.min(S - 6, Math.floor((e.clientY - r.top) / r.height * S) - 3));
    if (x !== last[0] || y !== last[1]) showWin(x, y);
  });
  NST.bus.on('work', () => { drawStack(); drawPix(); showWin(...last); });
})();

/* =========================================================================
   Capítulo 2 — convolución paso a paso
   ========================================================================= */
(function chapter2() {
  const N = 16, M = N - 2; // entrada 16×16 → feature map 14×14 (sin padding)
  /* Entradas de ejemplo: valores enteros 0..9 (0 = negro, 9 = blanco) */
  const fromCanvas = draw => {
    const c = document.createElement('canvas'); c.width = c.height = N; const g = c.getContext('2d');
    g.fillStyle = '#000'; g.fillRect(0, 0, N, N); g.fillStyle = g.strokeStyle = '#fff'; draw(g);
    const d = g.getImageData(0, 0, N, N).data; return Array.from({ length: N * N }, (_, i) => Math.round(d[i * 4] / 255 * 9));
  };
  const fromFn = f => Array.from({ length: N * N }, (_, i) => Math.max(0, Math.min(9, Math.round(f(i % N, Math.floor(i / N))))));
  const INPUTS = {
    'Cuadrado + diagonal': () => fromFn((x, y) => ((x >= 2 && x <= 7 && y >= 2 && y <= 7) || (x + y === 18 && x >= 6 && x <= 13) || (y === 13 && x >= 3 && x <= 13)) ? 9 : 0),
    'Letra A': () => fromCanvas(g => { g.font = 'bold 15px Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('A', 8, 9); }),
    'Círculo': () => fromFn((x, y) => Math.abs(Math.hypot(x - 7.5, y - 7.5) - 5.5) < .8 ? 9 : 0),
    'Rayas verticales': () => fromFn(x => x % 4 < 2 ? 9 : 0),
    'Rayas horizontales': () => fromFn((x, y) => y % 4 < 2 ? 9 : 0),
    'Rayas diagonales': () => fromFn((x, y) => (x + y) % 5 < 2 ? 9 : 0),
    'Tablero': () => fromFn((x, y) => ((x >> 2) + (y >> 2)) % 2 ? 9 : 0),
    'Degradado': () => fromFn(x => x * 9 / (N - 1)),
    'Punto aislado': () => fromFn((x, y) => x === 7 && y === 7 ? 9 : 0),
    'Ruido': () => fromFn(() => Math.random() * 9),
    'Imagen de trabajo': () => Array.from(NST.gray(NST.toTensor(NST.work.src, N), N * N), v => Math.round(v * 9)),
    'En blanco (dibuja)': () => new Array(N * N).fill(0),
  };
  const inG = $('#cInput'), kG = $('#cKernel'), outG = $('#cOutput'), calc = $('#cCalc');
  inG.style.gridTemplateColumns = `repeat(${N},auto)`; kG.style.gridTemplateColumns = 'repeat(3,auto)'; outG.style.gridTemplateColumns = `repeat(${M},auto)`;
  let inputName = 'Cuadrado + diagonal', IN = INPUTS[inputName]();
  const inC = []; for (let i = 0; i < N * N; i++) inC.push(el('div', 'c', inG));
  function paintInput() {
    IN.forEach((v, i) => { const c = inC[i], g = v / 9 * 255; c.textContent = v; c.style.background = rgbStr([g, g, g]); c.style.color = v > 4 ? '#111' : '#ddd'; });
  }
  // Dibujar: clic (o arrastrar) alterna las casillas entre 0 y 9
  let drawing = false, drawVal = 9;
  inG.addEventListener('mousedown', e => { const i = inC.indexOf(e.target); if (i < 0) return; drawing = true; drawVal = IN[i] > 4 ? 0 : 9; IN[i] = drawVal; paintInput(); reset(); e.preventDefault(); });
  inG.addEventListener('mouseover', e => { if (!drawing) return; const i = inC.indexOf(e.target); if (i < 0 || IN[i] === drawVal) return; IN[i] = drawVal; paintInput(); reset(); });
  addEventListener('mouseup', () => drawing = false);
  let K = KERNELS['Borde vertical'].slice();
  const kC = K.map((v, i) => {
    const c = el('div', 'c', kG), inp = el('input', '', c); inp.value = fmt(v);
    inp.addEventListener('change', () => { const x = parseFloat(inp.value); K[i] = isNaN(x) ? 0 : x; inp.value = fmt(K[i]); paintKernel(); reset(); });
    return c;
  });
  const outC = []; for (let i = 0; i < M * M; i++) outC.push(el('div', 'c', outG, ''));
  function paintKernel() {
    const m = Math.max(...K.map(Math.abs)) || 1;
    kC.forEach((c, i) => { const col = NST.diverging(K[i] / m); c.style.background = rgbStr(col); c.style.color = '#111'; c.firstChild.value = fmt(K[i]); });
  }
  const presets = $('#kPresets');
  Object.keys(KERNELS).forEach((n, i) => { const b = el('button', i === 0 ? 'on' : '', presets, n); b.dataset.n = n; });
  segInit(presets, d => { K = KERNELS[d.n].slice(); paintKernel(); reset(); });
  const inPick = $('#cInputs');
  Object.keys(INPUTS).forEach((n, i) => { const b = el('button', i === 0 ? 'on' : '', inPick, n); b.dataset.n = n; });
  segInit(inPick, d => { inputName = d.n; IN = INPUTS[d.n](); paintInput(); reset(); });
  NST.bus.on('work', () => { if (inputName === 'Imagen de trabajo') { IN = INPUTS[inputName](); paintInput(); reset(); } });

  let pos = 0, timer = null, full = [];
  function compute() {
    full = [];
    for (let y = 0; y < M; y++) for (let x = 0; x < M; x++) { let s = 0; for (let j = 0; j < 3; j++) for (let i = 0; i < 3; i++) s += IN[(y + j) * N + x + i] * K[j * 3 + i]; full.push(s); }
  }
  function clearHL() { inC.forEach(c => c.classList.remove('hl')); outC.forEach(c => c.classList.remove('hl')); kC.forEach(c => c.classList.remove('hl')); }
  function paintOut(p) {
    const s = full[p], m = Math.max(...full.map(Math.abs)) || 1, col = NST.diverging(s / m), o = outC[p];
    o.textContent = fmt(+s.toFixed(1)); o.style.background = rgbStr(col); o.style.color = '#111';
    return o;
  }
  function step() {
    if (pos >= M * M) { stop(); return false; }
    clearHL();
    const y = Math.floor(pos / M), x = pos % M; const terms = [];
    for (let j = 0; j < 3; j++) for (let i = 0; i < 3; i++) { const idx = (y + j) * N + x + i; inC[idx].classList.add('hl'); terms.push(`${IN[idx]}·${fmt(K[j * 3 + i])}`); }
    kC.forEach(c => c.classList.add('hl'));
    const o = paintOut(pos); o.classList.add('hl'); o.classList.remove('pop'); void o.offsetWidth; o.classList.add('pop');
    calc.innerHTML = `posición (${y},${x})<br>${terms.slice(0, 3).join(' + ')} +<br>${terms.slice(3, 6).join(' + ')} +<br>${terms.slice(6).join(' + ')}<span class="res">= ${fmt(+full[pos].toFixed(2))}</span>`;
    pos++; return true;
  }
  function stop() { clearTimeout(timer); timer = null; $('#cPlay').textContent = '▶ Reproducir'; $('#cPlay').classList.remove('running'); }
  function loop() { if (step()) timer = setTimeout(loop, 1100 / +$('#cSpeed').value); }
  function reset() {
    stop(); pos = 0; compute(); clearHL();
    outC.forEach(c => { c.textContent = ''; c.style.background = ''; });
    calc.innerHTML = 'Pulsa <b>Reproducir</b> o <b>Paso</b> para deslizar el filtro.';
  }
  $('#cPlay').addEventListener('click', () => {
    if (timer) { stop(); return; }
    if (pos >= M * M) reset();
    $('#cPlay').textContent = '❚❚ Pausa'; $('#cPlay').classList.add('running'); loop();
  });
  $('#cStep').addEventListener('click', () => { stop(); if (pos >= M * M) reset(); step(); });
  $('#cFill').addEventListener('click', () => {
    stop(); clearHL(); for (let p = 0; p < M * M; p++) paintOut(p); pos = M * M;
    calc.innerHTML = `Feature map completo (${M}×${M}).<br>Rojo: el patrón del filtro encaja.<br>Azul: aparece el patrón opuesto.`;
  });
  $('#cReset').addEventListener('click', reset);
  paintInput(); paintKernel(); reset();
  // Arranca solo la primera vez que se ve
  new IntersectionObserver((en, ob) => { if (en[0].isIntersecting) { ob.disconnect(); setTimeout(() => $('#cPlay').click(), 600); } }, { threshold: .3 }).observe(outG);
})();

/* =========================================================================
   Capítulo 3 — feature map de una imagen real
   ========================================================================= */
(function chapter3() {
  const S = 128, inCv = $('#fmIn'), outCv = $('#fmOut'), hist = $('#fmHist'), scan = $('#fmScan'), kv = $('#fmKernelView');
  kv.style.gridTemplateColumns = 'repeat(3,auto)';
  const kCells = []; for (let i = 0; i < 9; i++) kCells.push(el('div', 'c', kv));
  let K = KERNELS['Borde vertical'], gray = null, map = null, anim = null;
  const presets = $('#fmPresets');
  Object.keys(KERNELS).forEach((n, i) => { const b = el('button', i === 0 ? 'on' : '', presets, n); b.dataset.n = n; });
  segInit(presets, d => { K = KERNELS[d.n]; run(); });
  $('#fmRelu').addEventListener('change', () => { compute(); draw(S * S); drawHist(); });
  $('#fmRun').addEventListener('click', run);

  function compute() {
    const raw = NST.conv(gray, 1, S, S, Float32Array.from(K), null, 1, 3);
    map = $('#fmRelu').checked ? NST.relu(raw) : raw;
    $('#fmCap').textContent = $('#fmRelu').checked ? 'Feature map tras ReLU' : 'Feature map (sin ReLU)';
    const m = Math.max(...K.map(Math.abs)) || 1;
    kCells.forEach((c, i) => { c.textContent = fmt(K[i]); c.style.background = rgbStr(NST.diverging(K[i] / m)); c.style.color = '#111'; });
  }
  function draw(n) {
    outCv.width = S; outCv.height = S;
    const g = outCv.getContext('2d'), id = g.createImageData(S, S), d = id.data;
    let m = 1e-6; for (let i = 0; i < S * S; i++) m = Math.max(m, Math.abs(map[i]));
    const relu = $('#fmRelu').checked;
    for (let i = 0; i < S * S; i++) {
      const c = i < n ? (relu ? NST.magma(map[i] / m) : NST.diverging(map[i] / m)) : [20, 22, 30];
      d[i * 4] = c[0]; d[i * 4 + 1] = c[1]; d[i * 4 + 2] = c[2]; d[i * 4 + 3] = 255;
    }
    g.putImageData(id, 0, 0);
  }
  function drawHist() {
    const g = hist.getContext('2d'), W = hist.width, H = hist.height, B = 41;
    g.clearRect(0, 0, W, H);
    let m = 1e-6; for (let i = 0; i < map.length; i++) m = Math.max(m, Math.abs(map[i]));
    const bins = new Array(B).fill(0); for (let i = 0; i < map.length; i++) bins[Math.min(B - 1, Math.round((map[i] / m + 1) / 2 * (B - 1)))]++;
    const bm = Math.max(...bins), relu = $('#fmRelu').checked;
    bins.forEach((b, i) => {
      const v = i / (B - 1) * 2 - 1, h = Math.sqrt(b / bm) * (H - 24);
      g.fillStyle = rgbStr(relu ? NST.magma(Math.max(0, v)) : NST.diverging(v)); g.fillRect(i * W / B + 1, H - 16 - h, W / B - 2, h);
    });
    g.fillStyle = NST.css('--muted'); g.font = '11px system-ui'; g.fillText('−máx', 2, H - 3); g.fillText('0', W / 2 - 3, H - 3); g.fillText('+máx', W - 30, H - 3);
  }
  function run() {
    cancelAnimationFrame(anim); compute(); drawHist();
    let n = 0; const per = S * 1.6, sc = (inCv.clientWidth || 240) / S;
    scan.style.opacity = 1; scan.style.width = scan.style.height = (3 * sc) + 'px';
    const tick = () => {
      n = Math.min(S * S, n + per); draw(n);
      const y = Math.floor(n / S), x = n % S;
      scan.style.transform = `translate(${(x - 1) * sc}px,${(y - 1) * sc}px)`;
      if (n < S * S) anim = requestAnimationFrame(tick); else scan.style.opacity = 0;
    };
    tick();
  }
  NST.bus.on('work', () => {
    const t = NST.toTensor(NST.work.src, S); gray = NST.gray(t, S * S); NST.drawMap(inCv, gray, S, S, 'gray', 1);
    compute(); draw(S * S); drawHist();
  });
})();

/* =========================================================================
   Capítulo 4 — banco de filtros + pooling
   ========================================================================= */
(function chapter4() {
  const net = NST.net, S = 96, bank = $('#filterBank'), maps = $('#mapBank');
  const fC = [], mC = []; let st = null, sel = 2;
  for (let f = 0; f < 16; f++) {
    const c = el('canvas', '', bank); c.width = c.height = 5; c.title = net.l1info[f];
    const g = c.getContext('2d'), id = g.createImageData(5, 5); let m = 0;
    for (let i = 0; i < 75; i++) m = Math.max(m, Math.abs(net.w[0][f * 75 + i]));
    for (let i = 0; i < 25; i++) for (let ch = 0; ch < 3; ch++) id.data[i * 4 + ch] = 127.5 + 127.5 * net.w[0][f * 75 + ch * 25 + i] / m;
    for (let i = 0; i < 25; i++) id.data[i * 4 + 3] = 255;
    g.putImageData(id, 0, 0); fC.push(c); c.addEventListener('click', () => focus(f));
    const mc = el('canvas', '', maps); mc.title = 'Canal ' + f + ': ' + net.l1info[f]; mc.addEventListener('click', () => focus(f)); mC.push(mc);
  }
  function focus(f) {
    sel = f; fC.forEach((c, i) => c.classList.toggle('sel', i === f)); mC.forEach((c, i) => c.classList.toggle('sel', i === f));
    $('#focusTitle').textContent = `Canal ${f} · ${net.l1info[f]}`;
    if (!st) return;
    const N = S * S, fm = $('#focusMap');
    NST.drawMap(fm, st.a[0], S, S, 'magma', null, f * N);
    const ov = $('#focusOverlay'); ov.width = ov.height = S;
    const g = ov.getContext('2d'); g.drawImage(NST.work.src, 0, 0, S, S);
    const id = g.getImageData(0, 0, S, S), d = id.data; let m = 1e-6;
    for (let i = 0; i < N; i++) m = Math.max(m, st.a[0][f * N + i]);
    for (let i = 0; i < N; i++) { const v = st.a[0][f * N + i] / m, gr = (d[i * 4] + d[i * 4 + 1] + d[i * 4 + 2]) / 3 * .35; d[i * 4] = gr + v * 255; d[i * 4 + 1] = gr + v * 200; d[i * 4 + 2] = gr + v * 40; }
    g.putImageData(id, 0, 0);
    ov.style.top = fm.offsetTop + 'px'; ov.style.left = fm.offsetLeft + 'px';
    ov.style.opacity = $('#overlayChk').checked ? 1 : 0;
  }
  $('#overlayChk').addEventListener('change', () => focus(sel));
  NST.bus.on('work', () => {
    st = net.forward(NST.toTensor(NST.work.src, S), S);
    mC.forEach((c, f) => { c.classList.remove('show'); NST.drawMap(c, st.a[0], S, S, 'magma', null, f * S * S); setTimeout(() => c.classList.add('show'), 60 + f * 55); });
    focus(sel);
  });
  window.addEventListener('resize', () => focus(sel));

  /* --- pooling --- */
  const P = [1, 3, 2, 8, 5, 6, 1, 2, 0, 2, 9, 4, 7, 1, 3, 3];
  const pin = $('#poolIn'), pout = $('#poolOut'); pin.style.gridTemplateColumns = 'repeat(4,auto)'; pout.style.gridTemplateColumns = 'repeat(2,auto)';
  const pc = P.map(v => { const c = el('div', 'c', pin, v); const col = NST.magma(v / 9); c.style.background = rgbStr(col); c.style.color = textOn(col); return c; });
  const oc = [0, 1, 2, 3].map(() => el('div', 'c', pout, ''));
  oc.forEach(c => { c.style.width = c.style.height = '46px'; c.style.fontSize = '14px'; });
  let mode = 'max', busy = false;
  segInit($('#poolMode'), d => { mode = d.m; });
  async function play() {
    if (busy) return; busy = true;
    pc.forEach(c => c.className = 'c'); oc.forEach(c => { c.textContent = ''; c.style.background = ''; });
    for (let q = 0; q < 4; q++) {
      const qy = q >> 1, qx = q & 1, idx = [0, 1, 4, 5].map(o => (qy * 2) * 4 + qx * 2 + o);
      idx.forEach(i => pc[i].classList.add('q' + q)); await sleep(500);
      const vals = idx.map(i => P[i]); let v;
      if (mode === 'max') { v = Math.max(...vals); pc[idx[vals.indexOf(v)]].classList.add('win'); } else v = vals.reduce((a, b) => a + b) / 4;
      await sleep(400);
      const col = NST.magma(v / 9); oc[q].textContent = mode === 'max' ? v : v.toFixed(2); oc[q].style.background = rgbStr(col); oc[q].style.color = textOn(col);
      oc[q].classList.remove('pop'); void oc[q].offsetWidth; oc[q].classList.add('pop'); oc[q].classList.add('q' + q);
      await sleep(350);
    }
    busy = false;
  }
  $('#poolPlay').addEventListener('click', play);
  new IntersectionObserver((en, ob) => { if (en[0].isIntersecting) { ob.disconnect(); play(); } }, { threshold: .6 }).observe(pin);
})();

/* =========================================================================
   Capítulo 5 — campo receptivo, VGG y mapas por capa
   ========================================================================= */
(function chapter5() {
  const cvs = [0, 1, 2, 3].map(i => $('#rf' + i)), sizes = [15, 13, 11, 9], cell = 14;
  let gray = null, cur = [4, 4], hovering = false;
  function draw() {
    const [cy, cx] = cur, acc = NST.css('--accent'), acc2 = NST.css('--accent2'), line = NST.css('--line'), p2 = NST.css('--panel2');
    cvs.forEach((cv, l) => {
      const n = sizes[l], g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height);
      const span = 2 * (3 - l) + 1; // tamaño de la región influyente en esta capa
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        let base = p2;
        if (l === 0 && gray) { const v = gray[y * 15 + x] * 255; base = `rgb(${v},${v},${v})`; }
        g.fillStyle = base; g.fillRect(x * cell + 1, y * cell + 1, cell - 2, cell - 2);
        const inside = y >= cy && y < cy + span && x >= cx && x < cx + span;
        if (inside) { g.fillStyle = l === 3 ? acc2 : acc; g.globalAlpha = l === 0 ? .55 : .8; g.fillRect(x * cell + 1, y * cell + 1, cell - 2, cell - 2); g.globalAlpha = 1; }
        else { g.strokeStyle = line; g.strokeRect(x * cell + .5, y * cell + .5, cell - 1, cell - 1); }
      }
    });
  }
  cvs[3].addEventListener('mousemove', e => {
    const r = cvs[3].getBoundingClientRect(); hovering = true;
    const x = Math.floor((e.clientX - r.left) / r.width * 9), y = Math.floor((e.clientY - r.top) / r.height * 9);
    cur = [Math.max(0, Math.min(8, y)), Math.max(0, Math.min(8, x))]; draw();
  });
  cvs[3].addEventListener('mouseleave', () => hovering = false);
  let t = 0;
  setInterval(() => { if (hovering) return; t++; cur = [Math.floor(4 + 3.5 * Math.sin(t * .37)), Math.floor(4 + 3.5 * Math.cos(t * .23))]; draw(); }, 700);

  /* --- Diagrama VGG-19 --- */
  const svg = $('#vggSvg'), NS = 'http://www.w3.org/2000/svg';
  const sv = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); (parent || svg).appendChild(e); return e; };
  const blocks = [{ n: 2, h: 150, c: 64, s: 224 }, { n: 2, h: 120, c: 128, s: 112 }, { n: 4, h: 92, c: 256, s: 56 }, { n: 4, h: 66, c: 512, s: 28 }, { n: 4, h: 44, c: 512, s: 14 }];
  let x = 20; const mid = 115, slabs = [];
  sv('path', { d: `M10 ${mid + 95} H 950`, class: 'flow' });
  const inp = sv('g', { class: 'blk' });
  sv('rect', { x, y: mid - 75, width: 22, height: 150, rx: 3, fill: '#8fb6ff', opacity: .85 }, inp);
  sv('text', { x: x - 6, y: mid + 92 }, inp).textContent = 'entrada'; x += 46;
  const colors = ['#7a6cf5', '#a35cf0', '#d6559a', '#ea7a52', '#e8a83c'];
  blocks.forEach((b, bi) => {
    const x0 = x;
    for (let i = 0; i < b.n; i++) {
      const name = `conv${bi + 1}_${i + 1}`, g = sv('g', { class: 'blk' });
      const w = 8 + b.c / 64 * 3;
      sv('path', { d: `M${x} ${mid - b.h / 2} l10 -8 h${w} v${b.h} l-10 8 h-${w} z`, fill: colors[bi], opacity: .85 }, g);
      sv('rect', { x, y: mid - b.h / 2, width: w, height: b.h, fill: colors[bi] }, g);
      if (i === 0) { sv('circle', { cx: x + w / 2, cy: mid - b.h / 2 - 18, r: 5, fill: NST.css('--style') }, g); }
      if (bi === 3 && i === 1) { sv('rect', { x: x + w / 2 - 5, y: mid - b.h / 2 - 34, width: 10, height: 10, rx: 2, fill: NST.css('--content') }, g); }
      const tx = sv('text', { x: x + w / 2, y: mid + b.h / 2 + 18, 'text-anchor': 'middle', transform: `rotate(45 ${x + w / 2} ${mid + b.h / 2 + 18})` }, g); tx.textContent = name;
      slabs.push(g); x += w + 8;
    }
    const pg = sv('g', { class: 'blk' });
    sv('rect', { x, y: mid - b.h / 2 + 10, width: 5, height: b.h - 20, fill: NST.css('--muted'), opacity: .5 }, pg);
    slabs.push(pg); x += 18;
    sv('text', { x: (x0 + x - 18) / 2, y: bi % 2 ? 30 : 14, 'text-anchor': 'middle' }).textContent = `${b.s}×${b.s}×${b.c}`;
  });
  const fc = sv('g', { class: 'blk', opacity: .35 });
  [0, 1, 2].forEach(i => sv('rect', { x: x + i * 20, y: mid - 30, width: 12, height: 60, rx: 3, fill: NST.css('--muted') }, fc));
  sv('text', { x: x + 22, y: mid + 50, 'text-anchor': 'middle' }, fc).textContent = 'FC (no se usa)';
  const lg = sv('g', {});
  sv('circle', { cx: 30, cy: 238, r: 5, fill: NST.css('--style') }, lg); sv('text', { x: 40, y: 242 }, lg).textContent = 'capas de estilo (conv1_1 … conv5_1)';
  sv('rect', { x: 280, y: 233, width: 10, height: 10, rx: 2, fill: NST.css('--content') }, lg); sv('text', { x: 296, y: 242 }, lg).textContent = 'capa de contenido (conv4_2)';
  let k = 0;
  setInterval(() => { slabs.forEach((s, i) => s.style.opacity = i === k ? 1 : .55); k = (k + 1) % slabs.length; }, 160);

  /* --- Mapas reales de la mini-red --- */
  const dm = $('#depthMaps');
  NST.bus.on('work', () => {
    gray = NST.gray(NST.toTensor(NST.work.src, 15), 225); draw();
    const S = 96, st = NST.net.forward(NST.toTensor(NST.work.src, S), S);
    dm.innerHTML = '';
    const desc = ['bordes y colores', 'combinaciones: texturas', 'patrones más grandes'];
    st.a.forEach((a, l) => {
      const C = NST.net.C[l], s = st.sizes[l], N = s * s;
      const col = el('div', 'dcol reveal in', dm); el('h5', '', col, `relu${l + 1} · ${s}×${s}×${C} <span class="hint">— ${desc[l]}</span>`);
      const grid = el('div', 'dgrid', col);
      const means = []; for (let c = 0; c < C; c++) { let m = 0; for (let i = 0; i < N; i++) m += a[c * N + i]; means.push([m, c]); }
      means.sort((p, q) => q[0] - p[0]).slice(0, 8).forEach(([, c], i) => {
        const cv = el('canvas', '', grid); NST.drawMap(cv, a, s, s, 'magma', null, c * N); cv.title = 'canal ' + c;
        cv.style.animation = `pop .5s ${i * .06 + l * .25}s ease both`;
      });
    });
  });
})();

/* =========================================================================
   Capítulo 7 — matriz de Gram
   ========================================================================= */
(function chapter7() {
  const M = [[3, 0, 0, 3, 0, 0, 3, 0, 0], [0, 0, 2, 0, 2, 0, 2, 0, 0], [3, 1, 0, 3, 1, 0, 2, 1, 0]];
  const names = ['kernel A · azul', 'kernel B · trazo curvo', 'kernel C · amarillo'];
  const mapsD = $('#gramMaps'), flatD = $('#gramFlat'), mat = $('#gramMat'), calc = $('#gramCalc');
  const srcCells = [], flatCells = [], matCells = [];
  M.forEach((m, i) => {
    const box = el('div', 'mapbox', mapsD); el('div', '', box, names[i]);
    const g = el('div', 'mgrid', box); g.style.gridTemplateColumns = 'repeat(3,auto)';
    srcCells.push(m.map(v => { const c = el('div', 'c', g, v); const col = NST.magma(v / 3.5); c.style.background = rgbStr(col); c.style.color = textOn(col); return c; }));
  });
  M.forEach((m, i) => {
    const row = el('div', 'row', flatD); el('span', '', row, 'ABC'[i]);
    const g = el('div', 'mgrid', row); g.style.gridTemplateColumns = 'repeat(9,auto)';
    flatCells.push(m.map(v => { const c = el('div', 'c', g, v); const col = NST.magma(v / 3.5); c.style.background = rgbStr(col); c.style.color = textOn(col); c.style.visibility = 'hidden'; return c; }));
  });
  mat.style.gridTemplateColumns = 'repeat(3,auto)';
  for (let i = 0; i < 9; i++) matCells.push(el('div', 'c', mat, ''));
  const G = [0, 1, 2].map(i => [0, 1, 2].map(j => M[i].reduce((s, v, k) => s + v * M[j][k], 0)));
  const gmax = Math.max(...G.flat());
  calc.innerHTML = 'Tabla de coincidencias (3×3)';
  let busy = false;
  async function flatten() {
    if (busy) return; busy = true; $('#gramFlatBtn').disabled = true;
    for (let i = 0; i < 3; i++) for (let k = 0; k < 9; k++) {
      const s = srcCells[i][k], t = flatCells[i][k], rs = s.getBoundingClientRect(), rt = t.getBoundingClientRect();
      const fly = s.cloneNode(true); fly.classList.add('fly'); Object.assign(fly.style, { left: rs.left + 'px', top: rs.top + 'px', width: rs.width + 'px', height: rs.height + 'px', display: 'grid', placeItems: 'center', borderRadius: '5px', fontSize: '10px' });
      document.body.appendChild(fly);
      requestAnimationFrame(() => requestAnimationFrame(() => { fly.style.left = rt.left + 'px'; fly.style.top = rt.top + 'px'; }));
      setTimeout(() => { t.style.visibility = 'visible'; fly.remove(); }, 850);
      await sleep(45);
    }
    await sleep(900); busy = false; $('#gramMulBtn').disabled = false;
  }
  async function multiply() {
    if (busy) return; busy = true; $('#gramMulBtn').disabled = true;
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
      flatCells.flat().forEach(c => c.classList.remove('hl', 'hl2'));
      flatCells[i].forEach(c => c.classList.add('hl')); flatCells[j].forEach(c => c.classList.add('hl2'));
      matCells.forEach(c => c.classList.remove('hl')); matCells[i * 3 + j].classList.add('hl');
      const terms = M[i].map((v, k) => `${v}·${M[j][k]}`).filter((_, k) => M[i][k] * M[j][k] !== 0);
      calc.innerHTML = `¿Cuánto coinciden ${'ABC'[i]} y ${'ABC'[j]}?<br>casilla a casilla: ${terms.join(' + ') || 'nunca a la vez'}<span class="res">= ${G[i][j]}</span>`;
      await sleep(350);
      const c = matCells[i * 3 + j], col = NST.magma(G[i][j] / gmax); c.textContent = G[i][j]; c.style.background = rgbStr(col); c.style.color = textOn(col);
      c.classList.remove('pop'); void c.offsetWidth; c.classList.add('pop');
      await sleep(650);
    }
    flatCells.flat().forEach(c => c.classList.remove('hl', 'hl2')); matCells.forEach(c => c.classList.remove('hl'));
    calc.innerHTML = 'Diagonal: cuánto se enciende cada kernel.<br>Resto: cuánto coinciden dos kernels. <b>A y C</b> se encienden juntos → en este cuadro el azul y el amarillo van siempre juntos.';
    busy = false;
  }
  function reset() { if (busy) return; flatCells.flat().forEach(c => c.style.visibility = 'hidden'); matCells.forEach(c => { c.textContent = ''; c.style.background = ''; }); $('#gramFlatBtn').disabled = false; $('#gramMulBtn').disabled = true; calc.innerHTML = 'Tabla de coincidencias (3×3)'; }
  $('#gramFlatBtn').addEventListener('click', flatten); $('#gramMulBtn').addEventListener('click', multiply); $('#gramResetBtn').addEventListener('click', reset);

  /* --- experimento de desordenar --- */
  const S = 96, imgCv = $('#scImg'), mapCv = $('#scMap'), gramCv = $('#scGram'), CH = 2;
  let base = null, baseSt = null, baseG = null, cur = null, anim = null;
  const tilesIn = $('#scTiles');
  tilesIn.addEventListener('input', () => $('#scTilesOut').textContent = tilesIn.value + '×' + tilesIn.value);
  function analyse(t) {
    const st = NST.net.forward(t, S), G = NST.gram(st.a[0], 16, S * S);
    NST.drawMap(mapCv, st.a[0], S, S, 'magma', null, CH * S * S);
    gramCv.width = gramCv.height = 16; NST.drawMap(gramCv, G.map(v => Math.sqrt(Math.max(0, v))), 16, 16, 'magma'); // raíz: mejor contraste visual
    return { st, G };
  }
  function pearson(a, b) { let ma = 0, mb = 0; const n = a.length; for (let i = 0; i < n; i++) { ma += a[i]; mb += b[i]; } ma /= n; mb /= n; let s = 0, va = 0, vb = 0; for (let i = 0; i < n; i++) { const x = a[i] - ma, y = b[i] - mb; s += x * y; va += x * x; vb += y * y; } return s / Math.sqrt(va * vb + 1e-12); }
  function setSim(m, g) {
    const pm = Math.max(0, m) * 100, pg = Math.max(0, g) * 100;
    $('#simMap').style.width = pm + '%'; $('#simGram').style.width = pg + '%';
    $('#simMapV').textContent = pm.toFixed(0) + '%'; $('#simGramV').textContent = pg.toFixed(0) + '%';
  }
  function scramble() {
    const n = +tilesIn.value, ts = S / n, r = NST.rng(Date.now() & 0xffff);
    const perm = [...Array(n * n).keys()]; for (let i = perm.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [perm[i], perm[j]] = [perm[j], perm[i]]; }
    const src = el('canvas'); NST.drawRGB(src, base, S);
    const out = el('canvas'); out.width = out.height = S; const og = out.getContext('2d');
    perm.forEach((p, i) => og.drawImage(src, (p % n) * ts, Math.floor(p / n) * ts, ts, ts, (i % n) * ts, Math.floor(i / n) * ts, ts, ts));
    // animación de las piezas moviéndose
    cancelAnimationFrame(anim); const t0 = performance.now();
    imgCv.width = imgCv.height = S; const g = imgCv.getContext('2d');
    const tick = now => {
      const k = Math.min(1, (now - t0) / 900), e = k < .5 ? 2 * k * k : 1 - (-2 * k + 2) ** 2 / 2;
      g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
      perm.forEach((p, i) => {
        const sx = (p % n) * ts, sy = Math.floor(p / n) * ts, dx = (i % n) * ts, dy = Math.floor(i / n) * ts;
        g.drawImage(src, sx, sy, ts, ts, sx + (dx - sx) * e, sy + (dy - sy) * e, ts, ts);
      });
      if (k < 1) anim = requestAnimationFrame(tick); else {
        cur = NST.toTensor(out, S); const res = analyse(cur);
        const gs = 1 - Math.sqrt(res.G.reduce((s, v, i) => s + (v - baseG[i]) ** 2, 0) / baseG.reduce((s, v) => s + v * v, 0));
        setSim(pearson(res.st.a[0], baseSt.a[0]), gs);
      }
    };
    anim = requestAnimationFrame(tick);
  }
  function resetSc() { cancelAnimationFrame(anim); NST.drawRGB(imgCv, base, S); analyse(base); setSim(1, 1); }
  $('#scBtn').addEventListener('click', scramble); $('#scReset').addEventListener('click', resetSc);
  $('#scCh').textContent = CH;
  NST.bus.on('work', () => { base = NST.toTensor(NST.work.src, S); const r = analyse(base); baseSt = r.st; baseG = r.G; resetSc(); });
})();
