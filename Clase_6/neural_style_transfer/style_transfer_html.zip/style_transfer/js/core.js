/* =========================================================================
   core.js — utilidades: aleatoriedad, imágenes procedurales, tensores,
   mapas de color y una mini-CNN de 3 capas con retropropagación manual.
   Tensores: Float32Array con disposición [canal][fila][columna].
   ========================================================================= */
'use strict';

const NST = {};

/* ---------- PRNG reproducible ---------- */
NST.rng = function (seed) {
  let s = seed >>> 0;
  const f = () => { s += 0x6D2B79F5; let t = s; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  f.normal = () => { let u = 0, v = 0; while (u === 0) u = f(); v = f(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  return f;
};

/* ---------- Bus de eventos sencillo ---------- */
NST.bus = {
  h: {},
  on(e, f) { (this.h[e] = this.h[e] || []).push(f); },
  emit(e, d) { (this.h[e] || []).forEach(f => f(d)); }
};

/* =========================================================================
   Imágenes procedurales (dibujadas con Canvas 2D a 256×256)
   ========================================================================= */
NST.images = {};
function mk(size = 256) { const c = document.createElement('canvas'); c.width = c.height = size; return c; }

NST.images.paisaje = function () {
  const c = mk(), g = c.getContext('2d');
  let gr = g.createLinearGradient(0, 0, 0, 170); gr.addColorStop(0, '#3b7fd6'); gr.addColorStop(1, '#bfe3ff');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  g.fillStyle = '#ffd34d'; g.beginPath(); g.arc(196, 56, 26, 0, 7); g.fill();
  g.fillStyle = 'rgba(255,255,255,.9)';
  [[60, 50, 18], [80, 44, 22], [102, 52, 16]].forEach(([x, y, r]) => { g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); });
  g.fillStyle = '#6b7c9a'; g.beginPath(); g.moveTo(0, 170); g.lineTo(60, 90); g.lineTo(110, 150); g.lineTo(160, 80); g.lineTo(256, 165); g.lineTo(256, 256); g.lineTo(0, 256); g.fill();
  g.fillStyle = '#f4f7ff'; g.beginPath(); g.moveTo(60, 90); g.lineTo(74, 108); g.lineTo(48, 105); g.fill();
  g.beginPath(); g.moveTo(160, 80); g.lineTo(178, 97); g.lineTo(146, 98); g.fill();
  gr = g.createLinearGradient(0, 160, 0, 256); gr.addColorStop(0, '#5cb34a'); gr.addColorStop(1, '#2f7a2c');
  g.fillStyle = gr; g.beginPath(); g.moveTo(0, 180); g.quadraticCurveTo(128, 140, 256, 185); g.lineTo(256, 256); g.lineTo(0, 256); g.fill();
  g.fillStyle = '#c94c3c'; g.fillRect(40, 168, 62, 48);
  g.fillStyle = '#6d2a22'; g.beginPath(); g.moveTo(32, 170); g.lineTo(71, 136); g.lineTo(110, 170); g.fill();
  g.fillStyle = '#ffe9a8'; g.fillRect(50, 180, 14, 14); g.fillRect(78, 180, 14, 14);
  g.fillStyle = '#4a2b1a'; g.fillRect(64, 196, 14, 20);
  g.fillStyle = '#6b4226'; g.fillRect(184, 160, 10, 50);
  g.fillStyle = '#2e8b3e'; g.beginPath(); g.arc(189, 150, 30, 0, 7); g.fill();
  g.fillStyle = '#3fa64d'; g.beginPath(); g.arc(180, 142, 16, 0, 7); g.fill();
  return c;
};

NST.images.ciudad = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(7);
  let gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#0d1238'); gr.addColorStop(1, '#5a2d6e');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  g.fillStyle = '#f5f0d0'; g.beginPath(); g.arc(60, 50, 20, 0, 7); g.fill();
  for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(255,255,255,' + (.3 + r() * .7) + ')'; g.fillRect(r() * 256, r() * 120, 1.5, 1.5); }
  let x = 0;
  while (x < 256) {
    const w = 24 + r() * 26, h = 70 + r() * 130, y = 256 - h;
    const hue = 220 + r() * 50;
    g.fillStyle = `hsl(${hue},25%,${14 + r() * 12}%)`; g.fillRect(x, y, w, h);
    for (let wy = y + 6; wy < 250; wy += 10) for (let wx = x + 4; wx < x + w - 5; wx += 8)
      if (r() < .55) { g.fillStyle = r() < .8 ? '#ffd76a' : '#7fd6ff'; g.fillRect(wx, wy, 4, 5); }
    x += w + 2;
  }
  return c;
};

NST.images.flor = function () {
  const c = mk(), g = c.getContext('2d');
  const gr = g.createRadialGradient(128, 128, 10, 128, 128, 190); gr.addColorStop(0, '#d8f0c0'); gr.addColorStop(1, '#3f7f4a');
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  g.save(); g.translate(128, 128);
  for (let k = 0; k < 2; k++) for (let i = 0; i < 12; i++) {
    g.save(); g.rotate(i * Math.PI / 6 + k * Math.PI / 12);
    g.fillStyle = k ? '#ff8fb1' : '#e8366f'; g.strokeStyle = '#8e1240'; g.lineWidth = 2;
    g.beginPath(); g.ellipse(0, -(k ? 50 : 70), k ? 14 : 20, k ? 40 : 52, 0, 0, 7); g.fill(); g.stroke(); g.restore();
  }
  g.fillStyle = '#ffb627'; g.beginPath(); g.arc(0, 0, 30, 0, 7); g.fill();
  g.fillStyle = '#9c5a00'; for (let i = 0; i < 60; i++) { const a = i * 2.4, rr = Math.sqrt(i) * 3.7; g.beginPath(); g.arc(Math.cos(a) * rr, Math.sin(a) * rr, 1.8, 0, 7); g.fill(); }
  g.restore();
  return c;
};

NST.images.remolinos = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(3);
  g.fillStyle = '#0f2a5c'; g.fillRect(0, 0, 256, 256);
  const centers = [[70, 80, 1], [180, 60, -1], [150, 180, 1], [50, 200, -1]];
  const field = (x, y) => {
    let vx = .6, vy = 0;
    for (const [cx, cy, s] of centers) { const dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy + 300; vx += -s * dy * 900 / d2 / 30; vy += s * dx * 900 / d2 / 30; }
    const n = Math.hypot(vx, vy) || 1; return [vx / n, vy / n];
  };
  const pal = ['#f5d547', '#f7e98e', '#6fa8dc', '#cfe2f3', '#3d6fb6', '#e8a33a', '#ffffff'];
  g.lineCap = 'round';
  for (let i = 0; i < 1500; i++) {
    let x = r() * 256, y = r() * 256;
    g.strokeStyle = pal[(r() * pal.length) | 0]; g.globalAlpha = .55 + r() * .45; g.lineWidth = 2 + r() * 3;
    g.beginPath(); g.moveTo(x, y);
    for (let s = 0; s < 8; s++) { const [vx, vy] = field(x, y); x += vx * 3.2; y += vy * 3.2; g.lineTo(x, y); }
    g.stroke();
  }
  g.globalAlpha = 1;
  return c;
};

NST.images.mosaico = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(11);
  const pts = [], pal = ['#e63946', '#f1c453', '#2a9d8f', '#264653', '#f4a261', '#8ecae6', '#6a4c93', '#ffffff'];
  for (let i = 0; i < 55; i++) pts.push([r() * 256, r() * 256, pal[(r() * pal.length) | 0]]);
  const id = g.createImageData(256, 256), d = id.data;
  const rgb = pts.map(p => { const h = p[2]; return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; });
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    let b1 = 1e9, b2 = 1e9, bi = 0;
    for (let i = 0; i < pts.length; i++) { const dx = x - pts[i][0], dy = y - pts[i][1], dd = dx * dx + dy * dy; if (dd < b1) { b2 = b1; b1 = dd; bi = i; } else if (dd < b2) b2 = dd; }
    const edge = Math.sqrt(b2) - Math.sqrt(b1) < 3.2;
    const o = (y * 256 + x) * 4, col = rgb[bi];
    d[o] = edge ? 25 : col[0]; d[o + 1] = edge ? 22 : col[1]; d[o + 2] = edge ? 30 : col[2]; d[o + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  return c;
};

NST.images.ondas = function () {
  const c = mk(), g = c.getContext('2d');
  const pal = ['#7b1e3a', '#d1495b', '#edae49', '#f6e27f', '#d1495b'];
  for (let y = -20; y < 280; y += 3) {
    g.strokeStyle = pal[Math.floor(y / 12 + 20) % pal.length]; g.lineWidth = 4;
    g.beginPath();
    for (let x = 0; x <= 256; x += 4) { const yy = y + 10 * Math.sin(x / 18 + y / 30) + 6 * Math.sin(x / 7 - y / 11); x ? g.lineTo(x, yy) : g.moveTo(x, yy); }
    g.stroke();
  }
  return c;
};

NST.images.puntos = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(21);
  g.fillStyle = '#f3ead8'; g.fillRect(0, 0, 256, 256);
  const pal = ['#1d3557', '#457b9d', '#e63946', '#2a9d8f', '#f4a261', '#264653'];
  for (let i = 0; i < 1600; i++) { g.fillStyle = pal[(r() * pal.length) | 0]; g.beginPath(); g.arc(r() * 256, r() * 256, 1.5 + r() * 3.5, 0, 7); g.fill(); }
  return c;
};

NST.images.retrato = function () {
  const c = mk(), g = c.getContext('2d');
  g.fillStyle = '#7fb3d5'; g.fillRect(0, 0, 256, 256);
  g.fillStyle = '#2e4053'; g.beginPath(); g.ellipse(128, 250, 95, 70, 0, 0, 7); g.fill();           // hombros
  g.fillStyle = '#e0ac69'; g.fillRect(110, 150, 36, 40);                                               // cuello
  g.fillStyle = '#4a2c17'; g.beginPath(); g.ellipse(128, 100, 66, 72, 0, 0, 7); g.fill();             // pelo
  g.fillStyle = '#f1c27d'; g.beginPath(); g.ellipse(128, 115, 52, 62, 0, 0, 7); g.fill();             // cara
  g.fillStyle = '#4a2c17'; g.beginPath(); g.ellipse(128, 62, 56, 22, 0, Math.PI, 2 * Math.PI); g.fill(); // flequillo
  g.fillStyle = '#fff'; [[106, 110], [150, 110]].forEach(([x, y]) => { g.beginPath(); g.ellipse(x, y, 11, 7, 0, 0, 7); g.fill(); });
  g.fillStyle = '#3b2412'; [[106, 110], [150, 110]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill(); });
  g.strokeStyle = '#3b2412'; g.lineWidth = 3; [[94, 96, 118, 94], [138, 94, 162, 96]].forEach(([a, b, c2, d]) => { g.beginPath(); g.moveTo(a, b); g.lineTo(c2, d); g.stroke(); });
  g.strokeStyle = '#c68642'; g.beginPath(); g.moveTo(128, 115); g.lineTo(122, 138); g.lineTo(132, 140); g.stroke();
  g.strokeStyle = '#b03a2e'; g.lineWidth = 4; g.beginPath(); g.arc(128, 145, 16, .2 * Math.PI, .8 * Math.PI); g.stroke();
  return c;
};
NST.images.faro = function () {
  const c = mk(), g = c.getContext('2d');
  let gr = g.createLinearGradient(0, 0, 0, 150); gr.addColorStop(0, '#f6a35b'); gr.addColorStop(1, '#fbe3b0'); g.fillStyle = gr; g.fillRect(0, 0, 256, 160);
  gr = g.createLinearGradient(0, 150, 0, 256); gr.addColorStop(0, '#2e86c1'); gr.addColorStop(1, '#1b4f72'); g.fillStyle = gr; g.fillRect(0, 150, 256, 106);
  g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 2;
  for (let y = 165; y < 256; y += 14) { g.beginPath(); for (let x = 0; x <= 256; x += 8) g.lineTo(x, y + 3 * Math.sin(x / 10 + y)); g.stroke(); }
  g.fillStyle = '#5d4037'; g.beginPath(); g.moveTo(130, 256); g.lineTo(150, 170); g.lineTo(240, 160); g.lineTo(256, 256); g.fill();  // roca
  g.fillStyle = '#fff'; g.beginPath(); g.moveTo(178, 168); g.lineTo(186, 70); g.lineTo(210, 70); g.lineTo(218, 168); g.fill();     // torre
  g.fillStyle = '#c0392b'; [[90, 104], [130, 144]].forEach(([a, b]) => { g.beginPath(); g.moveTo(186 - (a - 70) * .08, a); g.lineTo(210 + (a - 70) * .08, a); g.lineTo(212 + (b - 70) * .08, b - 16); g.lineTo(184 - (b - 70) * .08, b - 16); g.fill(); });
  g.fillStyle = '#2c3e50'; g.fillRect(184, 56, 28, 14); g.fillStyle = '#ffeb3b'; g.fillRect(190, 58, 16, 10);
  g.fillStyle = 'rgba(255,235,59,.35)'; g.beginPath(); g.moveTo(198, 63); g.lineTo(40, 30); g.lineTo(40, 90); g.fill();
  g.fillStyle = '#fdd835'; g.beginPath(); g.arc(60, 140, 22, Math.PI, 2 * Math.PI); g.fill();
  return c;
};
NST.images.frutas = function () {
  const c = mk(), g = c.getContext('2d');
  g.fillStyle = '#6d4c41'; g.fillRect(0, 0, 256, 256); g.fillStyle = '#a1887f'; g.fillRect(0, 170, 256, 86);
  g.fillStyle = '#eceff1'; g.beginPath(); g.ellipse(128, 190, 100, 26, 0, 0, 7); g.fill();               // plato
  [[80, 160, 30, '#c62828'], [130, 150, 34, '#ef6c00'], [180, 162, 28, '#7cb342'], [105, 128, 24, '#fdd835']].forEach(([x, y, r, col]) => {
    const rg = g.createRadialGradient(x - r / 3, y - r / 3, 2, x, y, r); rg.addColorStop(0, '#fff'); rg.addColorStop(.25, col); rg.addColorStop(1, '#3e2723');
    g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  });
  g.strokeStyle = '#33691e'; g.lineWidth = 3; g.beginPath(); g.moveTo(130, 118); g.lineTo(134, 104); g.stroke();
  g.fillStyle = '#558b2f'; g.beginPath(); g.ellipse(142, 106, 10, 5, -.5, 0, 7); g.fill();
  g.fillStyle = '#1565c0'; g.fillRect(200, 60, 30, 105); g.fillStyle = '#0d47a1'; g.fillRect(208, 40, 14, 22);     // botella
  return c;
};
NST.images.acuarela = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(31);
  g.fillStyle = '#fbf7ef'; g.fillRect(0, 0, 256, 256);
  const pal = ['#f28b82', '#fbbc04', '#a7ffeb', '#81c995', '#aecbfa', '#d7aefb', '#fdcfe8'];
  g.globalCompositeOperation = 'multiply';
  for (let i = 0; i < 70; i++) {
    const x = r() * 256, y = r() * 256, rad = 15 + r() * 40, col = pal[(r() * pal.length) | 0];
    const rg = g.createRadialGradient(x, y, rad * .2, x, y, rad); rg.addColorStop(0, col + 'cc'); rg.addColorStop(.85, col + '66'); rg.addColorStop(1, col + '00');
    g.fillStyle = rg; g.beginPath(); for (let k = 0; k < 9; k++) { const a = k / 9 * 2 * Math.PI, q = rad * (.75 + r() * .3); g.lineTo(x + q * Math.cos(a), y + q * Math.sin(a)); } g.fill();
  }
  g.globalCompositeOperation = 'source-over';
  return c;
};
NST.images.cubismo = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(17);
  const pal = ['#8d6e63', '#d7ccc8', '#5d4037', '#a1887f', '#ffb74d', '#4e342e', '#90a4ae', '#bcaaa4'];
  g.fillStyle = '#795548'; g.fillRect(0, 0, 256, 256);
  g.lineWidth = 3; g.strokeStyle = '#2d1f1a';
  for (let i = 0; i < 60; i++) {
    const x = r() * 256, y = r() * 256, n = 3 + ((r() * 3) | 0), s = 25 + r() * 50;
    g.fillStyle = pal[(r() * pal.length) | 0]; g.beginPath();
    for (let k = 0; k < n; k++) g.lineTo(x + (r() - .5) * s * 2, y + (r() - .5) * s * 2);
    g.closePath(); g.fill(); g.stroke();
  }
  return c;
};
NST.images.neon = function () {
  const c = mk(), g = c.getContext('2d'), r = NST.rng(41);
  g.fillStyle = '#0b0420'; g.fillRect(0, 0, 256, 256);
  const pal = ['#ff00e5', '#00e5ff', '#76ff03', '#ffea00'];
  g.lineCap = 'round';
  for (let i = 0; i < 45; i++) {
    const col = pal[(r() * pal.length) | 0], x = r() * 256, y = r() * 256, a = r() * Math.PI, L = 30 + r() * 70;
    [[10, .15], [5, .35], [2, 1]].forEach(([w, al]) => {
      g.strokeStyle = col; g.globalAlpha = al; g.lineWidth = w;
      g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + Math.cos(a + 1) * L / 2, y + Math.sin(a + 1) * L / 2, x + Math.cos(a) * L, y + Math.sin(a) * L); g.stroke();
    });
  }
  g.globalAlpha = 1;
  return c;
};

NST.contentList = [['paisaje', 'Paisaje'], ['ciudad', 'Ciudad'], ['flor', 'Flor'], ['retrato', 'Retrato'], ['faro', 'Faro'], ['frutas', 'Bodegón']];
NST.styleList = [['remolinos', 'Remolinos'], ['mosaico', 'Mosaico'], ['ondas', 'Ondas'], ['puntos', 'Puntillismo'], ['acuarela', 'Acuarela'], ['cubismo', 'Cubismo'], ['neon', 'Neón']];
NST.cache = {};
NST.getImage = function (name) { if (!NST.cache[name]) NST.cache[name] = NST.images[name](); return NST.cache[name]; };

/* Carga un archivo subido → canvas cuadrado 256 (recorte central) */
NST.loadFile = function (file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const c = mk(), g = c.getContext('2d'), s = Math.min(im.width, im.height);
      g.drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, 256, 256);
      URL.revokeObjectURL(url); res(c);
    };
    im.onerror = rej; im.src = url;
  });
};

/* Canvas → tensor [3][S][S] en [0,1] */
NST.toTensor = function (src, S) {
  const c = mk(S), g = c.getContext('2d');
  g.imageSmoothingQuality = 'high'; g.drawImage(src, 0, 0, S, S);
  const d = g.getImageData(0, 0, S, S).data, N = S * S, t = new Float32Array(3 * N);
  for (let i = 0; i < N; i++) { t[i] = d[i * 4] / 255; t[N + i] = d[i * 4 + 1] / 255; t[2 * N + i] = d[i * 4 + 2] / 255; }
  return t;
};
NST.gray = function (t, N) { const o = new Float32Array(N); for (let i = 0; i < N; i++) o[i] = .299 * t[i] + .587 * t[N + i] + .114 * t[2 * N + i]; return o; };

/* =========================================================================
   Mapas de color y dibujo
   ========================================================================= */
const MAGMA = [[0, 0, 4], [28, 16, 68], [79, 18, 123], [129, 37, 129], [181, 54, 122], [229, 80, 100], [251, 135, 97], [254, 194, 135], [252, 253, 191]];
NST.magma = function (v) {
  v = Math.max(0, Math.min(1, v)) * (MAGMA.length - 1);
  const i = Math.min(MAGMA.length - 2, Math.floor(v)), f = v - i, a = MAGMA[i], b = MAGMA[i + 1];
  return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
};
NST.diverging = function (v) { // v en [-1,1]
  v = Math.max(-1, Math.min(1, v));
  return v < 0 ? [242 + (47 - 242) * -v, 242 + (111 - 242) * -v, 242 + (228 - 242) * -v]
               : [242 + (224 - 242) * v, 242 + (72 - 242) * v, 242 + (62 - 242) * v];
};

/* Dibuja un mapa (H×W) en un canvas con resolución nativa */
NST.drawMap = function (canvas, data, H, W, mode = 'magma', maxv = null, off = 0) {
  canvas.width = W; canvas.height = H;
  const g = canvas.getContext('2d'), id = g.createImageData(W, H), d = id.data, N = H * W;
  let m = maxv;
  if (m == null) { m = 1e-8; for (let i = 0; i < N; i++) m = Math.max(m, Math.abs(data[off + i])); }
  for (let i = 0; i < N; i++) {
    const v = data[off + i] / m, c = mode === 'div' ? NST.diverging(v) : mode === 'gray' ? [v * 255, v * 255, v * 255] : NST.magma(v);
    d[i * 4] = c[0]; d[i * 4 + 1] = c[1]; d[i * 4 + 2] = c[2]; d[i * 4 + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  return m;
};
/* Dibuja un tensor RGB [3][S][S] */
NST.drawRGB = function (canvas, t, S, setSize = true) {
  if (setSize) { canvas.width = S; canvas.height = S; }
  const tmp = setSize ? canvas : mk(S);
  const g = tmp.getContext('2d'), id = g.createImageData(S, S), d = id.data, N = S * S;
  for (let i = 0; i < N; i++) {
    d[i * 4] = Math.max(0, Math.min(255, t[i] * 255)); d[i * 4 + 1] = Math.max(0, Math.min(255, t[N + i] * 255));
    d[i * 4 + 2] = Math.max(0, Math.min(255, t[2 * N + i] * 255)); d[i * 4 + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  if (!setSize) { const cg = canvas.getContext('2d'); cg.imageSmoothingEnabled = true; cg.clearRect(0, 0, canvas.width, canvas.height); cg.drawImage(tmp, 0, 0, canvas.width, canvas.height); }
};
NST.drawSrc = function (canvas, src) { const g = canvas.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(src, 0, 0, canvas.width, canvas.height); };
NST.css = name => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

/* =========================================================================
   Operaciones de tensores
   ========================================================================= */
/* Convolución "same" (relleno con ceros), pesos w[co][ci][k][k] */
NST.conv = function (inp, Ci, H, W, w, b, Co, k) {
  const HW = H * W, out = new Float32Array(Co * HW), p = k >> 1;
  for (let co = 0; co < Co; co++) {
    const ob = co * HW;
    if (b) out.fill(b[co], ob, ob + HW);
    for (let ci = 0; ci < Ci; ci++) {
      const ib = ci * HW;
      for (let ky = 0; ky < k; ky++) for (let kx = 0; kx < k; kx++) {
        const wv = w[((co * Ci + ci) * k + ky) * k + kx]; if (wv === 0) continue;
        const dy = ky - p, dx = kx - p, y0 = Math.max(0, -dy), y1 = Math.min(H, H - dy), x0 = Math.max(0, -dx), x1 = Math.min(W, W - dx);
        for (let y = y0; y < y1; y++) { const o = ob + y * W, i = ib + (y + dy) * W + dx; for (let x = x0; x < x1; x++) out[o + x] += wv * inp[i + x]; }
      }
    }
  }
  return out;
};
/* Gradiente respecto a la entrada de la convolución */
NST.convBack = function (dOut, Ci, H, W, w, Co, k) {
  const HW = H * W, dIn = new Float32Array(Ci * HW), p = k >> 1;
  for (let co = 0; co < Co; co++) {
    const ob = co * HW;
    for (let ci = 0; ci < Ci; ci++) {
      const ib = ci * HW;
      for (let ky = 0; ky < k; ky++) for (let kx = 0; kx < k; kx++) {
        const wv = w[((co * Ci + ci) * k + ky) * k + kx]; if (wv === 0) continue;
        const dy = ky - p, dx = kx - p, y0 = Math.max(0, -dy), y1 = Math.min(H, H - dy), x0 = Math.max(0, -dx), x1 = Math.min(W, W - dx);
        for (let y = y0; y < y1; y++) { const o = ob + y * W, i = ib + (y + dy) * W + dx; for (let x = x0; x < x1; x++) dIn[i + x] += wv * dOut[o + x]; }
      }
    }
  }
  return dIn;
};
NST.relu = a => { const o = new Float32Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[i] > 0 ? a[i] : 0; return o; };
NST.avgpool = function (a, C, H, W) {
  const h = H >> 1, w = W >> 1, o = new Float32Array(C * h * w);
  for (let c = 0; c < C; c++) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = c * H * W + 2 * y * W + 2 * x; o[c * h * w + y * w + x] = .25 * (a[i] + a[i + 1] + a[i + W] + a[i + W + 1]);
  }
  return o;
};
NST.unpool = function (d, C, H, W) { // H,W = tamaño grande
  const h = H >> 1, w = W >> 1, o = new Float32Array(C * H * W);
  for (let c = 0; c < C; c++) for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) o[c * H * W + y * W + x] = .25 * d[c * h * w + (y >> 1) * w + (x >> 1)];
  return o;
};
/* Desenfoque gaussiano 3×3 por canal */
NST.blur = function (t, C, S, amt = 1) {
  const o = new Float32Array(t.length), k = [1, 2, 1];
  for (let c = 0; c < C; c++) for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    let s = 0, n = 0;
    for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
      const yy = y + j, xx = x + i; if (yy < 0 || xx < 0 || yy >= S || xx >= S) continue;
      const wv = k[j + 1] * k[i + 1]; s += wv * t[c * S * S + yy * S + xx]; n += wv;
    }
    const idx = c * S * S + y * S + x; o[idx] = t[idx] * (1 - amt) + amt * s / n;
  }
  return o;
};
/* Desplazamiento circular (jitter) */
NST.roll = function (t, C, S, dx, dy) {
  const o = new Float32Array(t.length);
  for (let c = 0; c < C; c++) for (let y = 0; y < S; y++) { const yy = ((y + dy) % S + S) % S; for (let x = 0; x < S; x++) o[c * S * S + yy * S + ((x + dx) % S + S) % S] = t[c * S * S + y * S + x]; }
  return o;
};
/* Matriz de Gram G = F Fᵀ / N */
NST.gram = function (F, C, N) {
  const G = new Float32Array(C * C);
  for (let i = 0; i < C; i++) for (let j = i; j < C; j++) {
    let s = 0; const a = i * N, b = j * N; for (let k = 0; k < N; k++) s += F[a + k] * F[b + k];
    G[i * C + j] = G[j * C + i] = s / N;
  }
  return G;
};
NST.cosine = function (a, b) { let s = 0, na = 0, nb = 0; for (let i = 0; i < a.length; i++) { s += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; } return s / Math.sqrt(na * nb + 1e-12); };

/* =========================================================================
   Mini-CNN: conv5×5(3→16) · ReLU · pool · conv3×3(16→24) · ReLU · pool · conv3×3(24→32) · ReLU
   ========================================================================= */
NST.Net = function () {
  this.C = [16, 24, 32]; this.K = [5, 3, 3];
  // ---- Capa 1: bordes orientados (Gabor) por canal de color + manchas de color ----
  const k = 5, C1 = 16, w1 = new Float32Array(C1 * 3 * k * k);
  const colors = [[1, 1, 1], [1, -1, 0], [-.5, -.5, 1]].map(v => { const n = Math.hypot(...v); return v.map(x => x / n); });
  this.l1info = [];
  let co = 0;
  const thetas = [0, Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4];
  const tName = ['—', '╲', '|', '╱'], cName = ['luz', 'rojo‑verde', 'azul‑amarillo'];
  for (let ci = 0; ci < 3; ci++) for (let t = 0; t < 4; t++) {
    const th = thetas[t];
    for (let y = 0; y < k; y++) for (let x = 0; x < k; x++) {
      const dy = y - 2, dx = x - 2, u = dx * Math.cos(th) + dy * Math.sin(th), v = -dx * Math.sin(th) + dy * Math.cos(th);
      const gab = Math.exp(-(u * u + v * v) / (2 * 1.6 * 1.6)) * Math.sin(2 * Math.PI * v / 4.2);
      for (let c = 0; c < 3; c++) w1[((co * 3 + c) * k + y) * k + x] = colors[ci][c] * gab;
    }
    this.l1info.push('Borde ' + tName[t] + ' · ' + cName[ci]); co++;
  }
  const blobs = [[1, -.5, -.5], [-.5, 1, -.5], [-.5, -.5, 1], [-1, -1, -1]], bName = ['mancha roja', 'mancha verde', 'mancha azul', 'mancha oscura'];
  blobs.forEach((bc, bi) => {
    for (let y = 0; y < k; y++) for (let x = 0; x < k; x++) {
      const g = Math.exp(-((y - 2) ** 2 + (x - 2) ** 2) / (2 * 1.3 * 1.3));
      for (let c = 0; c < 3; c++) w1[((co * 3 + c) * k + y) * k + x] = bc[c] * g;
    }
    this.l1info.push(bName[bi]); co++;
  });
  for (let f = 0; f < C1; f++) { let n = 0; for (let i = 0; i < 75; i++) n += w1[f * 75 + i] ** 2; n = Math.sqrt(n); for (let i = 0; i < 75; i++) w1[f * 75 + i] /= n; }
  this.w = [w1];
  // ---- Capas 2 y 3: filtros aleatorios (inicialización de He) ----
  const r = NST.rng(1234);
  [[16, 24], [24, 32]].forEach(([ci, cO]) => {
    const w = new Float32Array(cO * ci * 9), sd = Math.sqrt(2 / (ci * 9));
    for (let i = 0; i < w.length; i++) w[i] = r.normal() * sd;
    this.w.push(w);
  });
  this.b = [new Float32Array(16).fill(0), new Float32Array(24).fill(-.02), new Float32Array(32).fill(-.02)];
};
/* upTo: última capa que se calcula (0, 1 o 2) — ahorra tiempo si solo interesa la capa 1 */
NST.Net.prototype.forward = function (x, S, upTo = 2) {
  const N = S * S, x0 = new Float32Array(3 * N);
  for (let i = 0; i < 3 * N; i++) x0[i] = x[i] - .5;
  const [C1, C2, C3] = this.C, S2 = S >> 1, S3 = S >> 2, st = { S, sizes: [S, S2, S3], pre: [], a: [] };
  st.pre[0] = NST.conv(x0, 3, S, S, this.w[0], this.b[0], C1, 5); st.a[0] = NST.relu(st.pre[0]);
  if (upTo < 1) return st;
  const p1 = NST.avgpool(st.a[0], C1, S, S);
  st.pre[1] = NST.conv(p1, C1, S2, S2, this.w[1], this.b[1], C2, 3); st.a[1] = NST.relu(st.pre[1]);
  if (upTo < 2) return st;
  const p2 = NST.avgpool(st.a[1], C2, S2, S2);
  st.pre[2] = NST.conv(p2, C2, S3, S3, this.w[2], this.b[2], C3, 3); st.a[2] = NST.relu(st.pre[2]);
  return st;
};
/* dA: [dA1, dA2, dA3] (cualquiera puede ser null). Devuelve dL/dx */
NST.Net.prototype.backward = function (st, dA) {
  const [C1, C2, C3] = this.C, [S, S2, S3] = st.sizes;
  const mask = (d, pre) => { for (let i = 0; i < d.length; i++) if (pre[i] <= 0) d[i] = 0; return d; };
  let g2 = dA[1] ? Float32Array.from(dA[1]) : null, g1 = dA[0] ? Float32Array.from(dA[0]) : null;
  if (dA[2]) {
    const d3 = mask(Float32Array.from(dA[2]), st.pre[2]);
    const dp2 = NST.convBack(d3, C2, S3, S3, this.w[2], C3, 3), u = NST.unpool(dp2, C2, S2, S2);
    if (g2) for (let i = 0; i < u.length; i++) g2[i] += u[i]; else g2 = u;
  }
  if (g2) {
    mask(g2, st.pre[1]);
    const dp1 = NST.convBack(g2, C1, S2, S2, this.w[1], C2, 3), u = NST.unpool(dp1, C1, S, S);
    if (g1) for (let i = 0; i < u.length; i++) g1[i] += u[i]; else g1 = u;
  }
  if (!g1) return new Float32Array(3 * S * S);
  mask(g1, st.pre[0]);
  return NST.convBack(g1, 3, S, S, this.w[0], C1, 5);
};
NST.net = new NST.Net();

/* Imagen de trabajo global (capítulos 1–7) */
NST.work = { name: 'paisaje', src: null };
NST.setWork = function (name, src) { NST.work.name = name; NST.work.src = src || NST.getImage(name); NST.bus.emit('work', NST.work); };
