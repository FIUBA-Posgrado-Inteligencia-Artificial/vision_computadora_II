/* =========================================================================
   main.js — navegación, animaciones de scroll, portada y diagrama del bucle
   ========================================================================= */
'use strict';

/* ---------- Tema ---------- */
$('#themeBtn').addEventListener('click', () => {
  const root = document.documentElement, dark = root.dataset.theme ? root.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
  root.dataset.theme = dark ? 'light' : 'dark';
});

/* ---------- Progreso y capítulo activo ---------- */
addEventListener('scroll', () => {
  const h = document.documentElement; $('#progress').style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight) * 100) + '%';
}, { passive: true });
const links = $$('#chapters a');
const secObs = new IntersectionObserver(en => en.forEach(e => {
  if (e.isIntersecting) links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id));
}), { rootMargin: '-45% 0px -50% 0px' });
['intro', 'pixeles', 'kernel', 'featuremap', 'especializados', 'canales', 'profundidad', 'maximizar', 'visualizar', 'estilo', 'extraer', 'perdida', 'lab'].forEach(id => secObs.observe(document.getElementById(id)));

/* ---------- Aparición al hacer scroll ---------- */
const revObs = new IntersectionObserver(en => en.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); revObs.unobserve(e.target); } }), { threshold: .08 });
$$('.reveal').forEach(e => revObs.observe(e));

/* ---------- Portada: rejilla de "activaciones" con un filtro que barre ---------- */
(function hero() {
  const cv = $('#heroCanvas'), g = cv.getContext('2d'); let W, H, cell = 26, t = 0;
  function size() { const d = devicePixelRatio || 1; W = cv.clientWidth; H = cv.clientHeight; cv.width = W * d; cv.height = H * d; g.setTransform(d, 0, 0, d, 0, 0); }
  size(); addEventListener('resize', size);
  NST.drawSrc($('#heroContent'), NST.getImage('paisaje')); NST.drawSrc($('#heroStyle'), NST.getImage('remolinos'));
  function frame() {
    t += .012; g.clearRect(0, 0, W, H);
    const cols = Math.ceil(W / cell), rows = Math.ceil(H / cell);
    const kx = (Math.sin(t * .7) * .5 + .5) * cols, ky = (Math.cos(t * .5) * .5 + .5) * rows;
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const v = .5 + .5 * Math.sin(x * .35 + t * 2) * Math.cos(y * .3 - t * 1.3) * Math.sin((x + y) * .12 + t);
      const d = Math.hypot(x - kx, y - ky), boost = Math.exp(-d * d / 18);
      const c = NST.magma(Math.min(1, v * .55 + boost * .6));
      g.fillStyle = `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${.18 + boost * .6})`;
      g.fillRect(x * cell + 2, y * cell + 2, cell - 4, cell - 4);
    }
    g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 2;
    g.strokeRect((Math.floor(kx) - 1) * cell, (Math.floor(ky) - 1) * cell, cell * 3, cell * 3);
    if (visible) requestAnimationFrame(frame);
  }
  // Solo se anima mientras la portada está a la vista (deja la CPU libre para los demos)
  let visible = false;
  new IntersectionObserver(en => {
    const was = visible; visible = en[0].isIntersecting;
    if (visible && !was && !matchMedia('(prefers-reduced-motion: reduce)').matches) frame();
  }).observe($('#intro'));
})();

/* ---------- Diagrama del bucle de optimización (capítulo 8) ---------- */
(function loopDiagram() {
  const svg = $('#loopSvg'), NS = 'http://www.w3.org/2000/svg';
  const sv = (tag, a, p) => { const e = document.createElementNS(NS, tag); for (const k in a) e.setAttribute(k, a[k]); (p || svg).appendChild(e); return e; };
  const cC = NST.css('--content'), cS = NST.css('--style'), cT = NST.css('--total'), cG = NST.css('--accent2');
  const defs = sv('defs', {});
  [['ac', cC], ['as', cS], ['at', cT], ['ag', cG]].forEach(([id, col]) => {
    const m = sv('marker', { id, viewBox: '0 0 10 10', refX: 9, refY: 5, markerWidth: 7, markerHeight: 7, orient: 'auto-start-reverse' }, defs);
    sv('path', { d: 'M0 0 L10 5 L0 10 z', fill: col }, m);
  });
  function box(x, y, w, h, t, sub, col) {
    const g = sv('g', { class: 'box' }); sv('rect', { x, y, width: w, height: h, rx: 12, style: col ? `stroke:${col}` : '' }, g);
    sv('text', { x: x + w / 2, y: y + (sub ? h / 2 - 2 : h / 2 + 5) }, g).textContent = t;
    if (sub) sv('text', { x: x + w / 2, y: y + h / 2 + 15, class: 'sub' }, g).textContent = sub;
    return g;
  }
  function link(d, col, mk, dur) {
    const p = sv('path', { d, class: 'lnk', stroke: col, 'marker-end': `url(#${mk})` });
    const c = sv('circle', { r: 4.5, fill: col });
    const am = sv('animateMotion', { dur: dur + 's', repeatCount: 'indefinite', path: d }, c);
    return p;
  }
  box(20, 20, 150, 56, 'Foto', 'contenido', cC);
  box(20, 152, 150, 56, 'Imagen nueva', 'sus píxeles cambian', cT);
  box(20, 284, 150, 56, 'Cuadro', 'estilo', cS);
  const cnn = sv('g', { class: 'box' }); sv('rect', { x: 250, y: 20, width: 150, height: 320, rx: 14 }, cnn);
  sv('text', { x: 325, y: 172 }, cnn).textContent = 'CNN congelada';
  sv('text', { x: 325, y: 192, class: 'sub' }, cnn).textContent = '(pesos fijos)';
  for (let i = 0; i < 5; i++) sv('rect', { x: 270 + i * 23, y: 60 + i * 8, width: 16, height: 70 - i * 10, rx: 3, fill: cT, opacity: .35 + i * .1 }, cnn);
  for (let i = 0; i < 5; i++) sv('rect', { x: 270 + i * 23, y: 230 + i * 8, width: 16, height: 70 - i * 10, rx: 3, fill: cT, opacity: .35 + i * .1 }, cnn);
  box(480, 20, 170, 56, 'Plano de la foto', 'kernels de forma', cC);
  box(480, 152, 170, 56, 'Plano y receta', 'de la imagen nueva', cT);
  box(480, 284, 170, 56, 'Receta del cuadro', 'kernels de estilo', cS);
  box(730, 20, 200, 56, 'Pérdida de contenido', '¿formas en su sitio?', cC);
  box(730, 152, 200, 56, 'Pérdida total', 'α·contenido + β·estilo', cT);
  box(730, 284, 200, 56, 'Pérdida de estilo', '¿misma receta?', cS);
  link('M170 48 H246', cC, 'ac', 1.2); link('M170 180 H246', cT, 'at', 1.2); link('M170 312 H246', cS, 'as', 1.2);
  link('M400 48 H476', cC, 'ac', 1.2); link('M400 180 H476', cT, 'at', 1.2); link('M400 312 H476', cS, 'as', 1.2);
  link('M650 48 H726', cC, 'ac', 1.2); link('M650 312 H726', cS, 'as', 1.2);
  link('M650 170 C 690 170 690 60 726 60', cT, 'at', 1.4); link('M650 190 C 690 190 690 300 726 300', cT, 'at', 1.4);
  link('M830 76 V148', cC, 'ac', 1); link('M830 284 V212', cS, 'as', 1);
  const back = link('M930 180 H950 V354 H8 V180 H16', cG, 'ag', 4);
  back.style.strokeWidth = 3;
  sv('text', { x: 480, y: 376, class: 'lbl', style: `fill:${cG};font-weight:700` }).textContent = 'Adam ajusta los píxeles para que la pérdida total baje · se repite cientos de veces';
})();

/* ---------- Balanza α / β (capítulo 11) ---------- */
(function balance() {
  const svg = $('#balSvg'), NS = 'http://www.w3.org/2000/svg', r = $('#balR');
  const sv = (tag, a, p) => { const e = document.createElementNS(NS, tag); for (const k in a) e.setAttribute(k, a[k]); (p || svg).appendChild(e); return e; };
  const cC = NST.css('--content'), cS = NST.css('--style'), ink = NST.css('--muted');
  sv('path', { d: 'M180 120 L160 175 L200 175 Z', fill: ink });
  sv('rect', { x: 120, y: 175, width: 120, height: 6, rx: 3, fill: ink });
  const beam = sv('g', { style: 'transition:transform .5s cubic-bezier(.3,1.4,.5,1);transform-origin:180px 120px' });
  sv('rect', { x: 40, y: 116, width: 280, height: 8, rx: 4, fill: ink }, beam);
  const pan = (x, col, label, icon) => {
    const g = sv('g', {}, beam);
    sv('line', { x1: x, y1: 120, x2: x - 30, y2: 165, stroke: ink }, g); sv('line', { x1: x, y1: 120, x2: x + 30, y2: 165, stroke: ink }, g);
    sv('path', { d: `M${x - 38} 165 Q${x} 185 ${x + 38} 165 Z`, fill: col }, g);
    const t = sv('text', { x, y: 105, 'text-anchor': 'middle', 'font-size': 14, 'font-weight': 700, fill: col }, g); t.textContent = label;
    icon(g, x);
    return g;
  };
  const w1 = pan(70, cC, 'α · contenido', (g, x) => { sv('path', { d: `M${x - 14} 160 v-14 l14 -12 l14 12 v14 z`, fill: '#fff', stroke: cC, 'stroke-width': 2 }, g); });
  const w2 = pan(290, cS, 'β · estilo', (g, x) => { sv('path', { d: `M${x - 16} 156 q8 -16 16 0 t16 0`, fill: 'none', stroke: '#fff', 'stroke-width': 3 }, g); });
  const TXT = [
    [15, 'Casi solo contenido: la imagen nueva se queda prácticamente igual que la foto; el estilo apenas se nota.'],
    [40, 'Más contenido que estilo: la foto se reconoce perfectamente, con los colores y algo de la textura del cuadro.'],
    [60, 'Equilibrio: las formas de la foto se reconocen bien, pintadas con los colores y trazos del cuadro. Suele ser lo que se busca.'],
    [85, 'Más estilo: dominan los trazos del cuadro; las formas siguen ahí, pero deformadas.'],
    [101, 'Casi solo estilo: sale la textura del cuadro (como el intento 2 del capítulo 10) y la foto casi desaparece.'],
  ];
  function upd() {
    const v = +r.value, ang = (v - 50) / 50 * 14;
    beam.style.transform = `rotate(${ang}deg)`;
    [w1, w2].forEach(g => { g.style.transformBox = 'fill-box'; g.style.transformOrigin = '50% 0'; g.style.transform = `rotate(${-ang}deg)`; g.style.transition = 'transform .5s cubic-bezier(.3,1.4,.5,1)'; });
    $('#balText').innerHTML = `<b>α = ${((100 - v) / 100).toFixed(2)}, β = ${(v / 100).toFixed(2)}</b><br>` + TXT.find(([m]) => v < m)[1];
  }
  r.addEventListener('input', upd); upd();
})();

/* ---------- Arranque ---------- */
NST.setWork('paisaje');
NST.fvInit();
NST.labInit();
PAT.kxInit();
PAT.mxInit();
PAT.exInit();
// El recorrido guiado del capítulo 4 se reproduce al llegar a él
new IntersectionObserver((en, ob) => { if (en[0].isIntersecting) { ob.disconnect(); PAT.kxInit(); } }, { threshold: .4 }).observe($('#kxFm'));
