/* =========================================================================
   lab.js — capítulo 6 (visualización de features por optimización)
            y capítulo 9 (transferencia de estilo en vivo)
   ========================================================================= */
'use strict';

/* Gráfica de líneas sencilla (escala log opcional) */
function lineChart(cv, series, { log = false, colors = [], maxPts = 400 } = {}) {
  const g = cv.getContext('2d'), W = cv.width, H = cv.height, pad = 8;
  g.clearRect(0, 0, W, H);
  let mn = Infinity, mx = -Infinity, len = 0;
  series.forEach(s => { len = Math.max(len, s.length); s.forEach(v => { const y = log ? Math.log10(Math.max(v, 1e-6)) : v; if (isFinite(y)) { mn = Math.min(mn, y); mx = Math.max(mx, y); } }); });
  if (!isFinite(mn)) return;
  if (mx - mn < 1e-6) { mx += .5; mn -= .5; }
  g.strokeStyle = NST.css('--line'); g.lineWidth = 1;
  for (let i = 0; i <= 3; i++) { const y = pad + (H - 2 * pad) * i / 3; g.beginPath(); g.moveTo(pad, y); g.lineTo(W - pad, y); g.stroke(); }
  series.forEach((s, si) => {
    if (!s.length) return;
    g.strokeStyle = colors[si] || NST.css('--accent'); g.lineWidth = 2; g.beginPath();
    const step = Math.max(1, Math.floor(s.length / maxPts));
    for (let i = 0; i < s.length; i += step) {
      const v = log ? Math.log10(Math.max(s[i], 1e-6)) : s[i];
      const x = pad + (W - 2 * pad) * i / Math.max(1, len - 1), y = H - pad - (H - 2 * pad) * (v - mn) / (mx - mn);
      i ? g.lineTo(x, y) : g.moveTo(x, y);
    }
    g.stroke();
  });
}

/* =========================================================================
   Capítulo 6 — Feature Visualization
   ========================================================================= */
(function chapter6() {
  const net = NST.net, S = 48;
  let layer = 0, chan = 2, obj = 'channel', x = null, iter = 0, running = false, hist = [], raf = null;
  const img = $('#fvImg'), gradCv = $('#fvGrad'), chart = $('#fvChart'), steps = $$('#fvSteps li'), pipe = $$('#fvPipe span');
  const chanIn = $('#fvChan'), lrIn = $('#fvLr');

  function noise(n, seed) { const r = NST.rng(seed), t = new Float32Array(n); for (let i = 0; i < n; i++) t[i] = .5 + r.normal() * .08; return t; }
  function setStep(i) { steps.forEach((s, k) => s.classList.toggle('on', k === i)); }

  /* Un paso de Adam sobre la pérdida L = 1 − promedio(FM normalizado a [0,1]).
     opts.ref = valor de activación que se considera "blanco" (1). Devuelve [x nuevo, loss, gradiente] */
  function ascend(x, S, layer, chan, obj, opts, it, r) {
    const jit = opts.jitter ? (layer === 2 ? 4 : 2) : 0, ref = opts.ref || 1;
    const dx = jit ? Math.round((r() * 2 - 1) * jit) : 0, dy = jit ? Math.round((r() * 2 - 1) * jit) : 0;
    const xj = jit ? NST.roll(x, 3, S, dx, dy) : x;
    const st = net.forward(xj, S, layer), s = st.sizes[layer], N = s * s, C = net.C[layer], a = st.a[layer];
    const dA = [null, null, null], d = new Float32Array(C * N); let fm = 0;
    // d = −∂L/∂a (dirección que reduce la pérdida); los píxeles ya saturados (FM = 1) no aportan gradiente
    if (obj === 'channel') { for (let i = 0; i < N; i++) { const v = a[chan * N + i] / ref; fm += Math.min(1, v) / N; if (v < 1) d[chan * N + i] = 1 / (N * ref); } }
    else if (obj === 'neuron') { const c = (s >> 1) * s + (s >> 1), v = a[chan * N + c] / ref; fm = Math.min(1, v); if (v < 1) d[chan * N + c] = 1 / ref; }
    else { for (let i = 0; i < C * N; i++) { const v = a[i] / ref; fm += Math.min(1, v) / (C * N); if (v < 1) d[i] = 1 / (C * N * ref); } }
    dA[layer] = d;
    let g = net.backward(st, dA);
    if (jit) g = NST.roll(g, 3, S, -dx, -dy);
    const out = new Float32Array(x.length), A = opts.adam;
    A.t++; const c1 = 1 - .9 ** A.t, c2 = 1 - .999 ** A.t;
    for (let i = 0; i < x.length; i++) {
      const gi = -g[i]; // gradiente de la pérdida
      A.m[i] = .9 * A.m[i] + .1 * gi; A.v[i] = .999 * A.v[i] + .001 * gi * gi;
      let v = x[i] - opts.lr * (A.m[i] / c1) / (Math.sqrt(A.v[i] / c2) + 1e-8);
      if (opts.decay) v -= .006 * (v - .5);
      out[i] = v;
    }
    const val = 1 - fm;
    let res = out;
    if (opts.blur && it % 4 === 0) res = NST.blur(out, 3, S, .5);
    for (let i = 0; i < res.length; i++) res[i] = Math.max(0, Math.min(1, res[i]));
    return [res, val, g];
  }
  const adamState = n => ({ m: new Float32Array(n), v: new Float32Array(n), t: 0 });
  let adam = adamState(3 * S * S), curRef = 1;
  const opts = () => ({ jitter: $('#fvJitter').checked, blur: $('#fvBlur').checked, decay: $('#fvDecay').checked, lr: +lrIn.value / 400, adam, ref: curRef });

  /* Para mostrar mejor el resultado, se estira el contraste de la imagen */
  function drawVis(cv, t, S) {
    const N = S * S, o = new Float32Array(t.length);
    for (let c = 0; c < 3; c++) {
      let mn = 1, mx = 0; for (let i = 0; i < N; i++) { mn = Math.min(mn, t[c * N + i]); mx = Math.max(mx, t[c * N + i]); }
      const lo = Math.min(mn, .5 - .05), hi = Math.max(mx, .5 + .05);
      for (let i = 0; i < N; i++) o[c * N + i] = (t[c * N + i] - lo) / (hi - lo);
    }
    NST.drawRGB(cv, o, S, false);
  }
  function drawGrad(g) {
    const N = S * S, m = new Float32Array(N);
    for (let i = 0; i < N; i++) m[i] = Math.abs(g[i]) + Math.abs(g[N + i]) + Math.abs(g[2 * N + i]);
    NST.drawMap(gradCv, m, S, S, 'magma');
  }
  const rng = NST.rng(99);
  function reset() {
    stop(); iter = 0; hist = []; x = noise(3 * S * S, (Math.random() * 1e6) | 0); adam = adamState(3 * S * S);
    img.width = img.height = 256; drawVis(img, x, S);
    const gg = gradCv.getContext('2d'); gradCv.width = gradCv.height = S; gg.fillStyle = '#000'; gg.fillRect(0, 0, S, S);
    $('#fvIter').textContent = 'iteración 0 · ruido aleatorio'; chart.getContext('2d').clearRect(0, 0, chart.width, chart.height);
    setStep(1); pipe.forEach(p => p.classList.remove('on'));
  }
  function stop() { running = false; cancelAnimationFrame(raf); $('#fvRun').textContent = '▶ Optimizar'; $('#fvRun').classList.remove('running'); }
  function frame() {
    if (!running) return;
    const t0 = performance.now(); let g = null, v = 0; const o = opts();
    while (performance.now() - t0 < 14) { [x, v, g] = ascend(x, S, layer, chan, obj, o, iter, rng); hist.push(v); iter++; }
    drawVis(img, x, S); drawGrad(g); lineChart(chart, [hist], { colors: [NST.css('--accent2')] });
    $('#fvIter').textContent = `iteración ${iter} · loss ${v.toFixed(3)}`;
    const ph = Math.floor(performance.now() / 180) % 5; pipe.forEach((p, i) => p.classList.toggle('on', i === ph));
    setStep(ph < 2 ? 2 : ph === 2 ? 2 : ph === 3 ? 3 : (Math.floor(performance.now() / 360) % 2 ? 4 : 5));
    if (iter >= 600) { stop(); setStep(6); return; }
    raf = requestAnimationFrame(frame);
  }
  $('#fvRun').addEventListener('click', () => {
    if (running) { stop(); return; }
    if (iter >= 600) reset();
    running = true; $('#fvRun').textContent = '❚❚ Pausa'; $('#fvRun').classList.add('running'); setStep(0);
    setTimeout(() => { if (running) raf = requestAnimationFrame(frame); }, 350);
  });
  $('#fvReset').addEventListener('click', reset);
  segInit($('#fvLayer'), d => {
    layer = +d.l - 1; chanIn.max = net.C[layer] - 1; if (chan > net.C[layer] - 1) chan = 0; chanIn.value = chan; $('#fvChanOut').textContent = chan;
    $('#galLayer').textContent = d.l; reset(); dataset();
  });
  chanIn.addEventListener('input', () => { chan = +chanIn.value; $('#fvChanOut').textContent = chan + (layer === 0 ? ' · ' + net.l1info[chan] : ''); reset(); dataset(); });
  segInit($('#fvObj'), d => { obj = d.o; reset(); });
  lrIn.addEventListener('input', () => $('#fvLrOut').textContent = (+lrIn.value / 400).toFixed(3));
  ['#fvJitter', '#fvBlur', '#fvDecay'].forEach(s => $(s).addEventListener('change', () => { if (!running) reset(); }));

  /* --- Ejemplos del "dataset" --- */
  const DS = 96, dsCache = [];
  function ensureCache() {
    if (dsCache.length) return;
    [...NST.contentList, ...NST.styleList].forEach(([k]) => { const src = NST.getImage(k); dsCache.push({ src, st: net.forward(NST.toTensor(src, DS), DS) }); });
  }
  /* "Blanco" (FM = 1) = 1.5 × la mayor activación de ese canal en las imágenes de ejemplo */
  function chanRef(L, c) {
    ensureCache(); const N = (DS >> L) ** 2; let m = 1e-3;
    dsCache.forEach(d => { const a = d.st.a[L]; for (let i = 0; i < N; i++) m = Math.max(m, a[c * N + i]); });
    return 1.5 * m;
  }
  function dataset() {
    ensureCache();
    const s = DS >> layer, N = s * s, rf = [12, 18, 28][layer], cand = [];
    dsCache.forEach((d, di) => {
      const a = d.st.a[layer].slice(chan * N, chan * N + N), used = new Uint8Array(N);
      for (let k = 0; k < 3; k++) { // 3 máximos por imagen con supresión de vecinos
        let bi = -1, bv = 0; for (let i = 0; i < N; i++) if (!used[i] && a[i] > bv) { bv = a[i]; bi = i; }
        if (bi < 0) break;
        const by = Math.floor(bi / s), bx = bi % s, rad = Math.max(2, Math.ceil(rf / (DS / s) / 2));
        for (let y = by - rad; y <= by + rad; y++) for (let x = bx - rad; x <= bx + rad; x++) if (y >= 0 && x >= 0 && y < s && x < s) used[y * s + x] = 1;
        cand.push({ v: bv, di, y: (by + .5) * DS / s, x: (bx + .5) * DS / s });
      }
    });
    cand.sort((p, q) => q.v - p.v);
    curRef = chanRef(layer, chan);
    const box = $('#fvDataset'); box.innerHTML = '';
    cand.slice(0, 8).forEach((c, i) => {
      const f = el('figure', '', box), cv = el('canvas', '', f); cv.width = cv.height = 84; f.style.animationDelay = i * .05 + 's';
      const sc = 256 / DS, half = rf / 2 * sc, g = cv.getContext('2d');
      g.imageSmoothingEnabled = false; g.drawImage(dsCache[c.di].src, c.x * sc - half, c.y * sc - half, 2 * half, 2 * half, 0, 0, 84, 84);
      el('figcaption', '', f, c.v.toFixed(2));
    });
  }

  /* --- Galería --- */
  let galBusy = false;
  $('#galleryBtn').addEventListener('click', async () => {
    if (galBusy) return; galBusy = true; $('#galleryBtn').disabled = true;
    const L = layer, C = net.C[L], gal = $('#gallery'), GS = 32, o = { jitter: true, blur: true, decay: true, lr: .05 }; gal.innerHTML = '';
    for (let c = 0; c < C; c++) {
      const f = el('figure', '', gal), cv = el('canvas', '', f); cv.width = cv.height = 110;
      el('figcaption', '', f, L === 0 ? `${c} · ${net.l1info[c]}` : `capa ${L + 1} · canal ${c}`);
      let t = noise(3 * GS * GS, 1000 + c); const r = NST.rng(c);
      o.adam = adamState(3 * GS * GS); o.ref = chanRef(L, c);
      for (let it = 0; it < 70; it++) { [t] = ascend(t, GS, L, c, 'channel', o, it, r); if (it % 10 === 9) { drawVis(cv, t, GS); await sleep(0); } }
      drawVis(cv, t, GS);
    }
    galBusy = false; $('#galleryBtn').disabled = false;
  });

  NST.fvInit = () => { reset(); dataset(); $('#fvChanOut').textContent = chan + ' · ' + net.l1info[chan]; };
})();

/* =========================================================================
   Capítulo 9 — Transferencia de estilo en vivo
   ========================================================================= */
(function chapter9() {
  const net = NST.net;
  const st = { content: NST.getImage('paisaje'), style: NST.getImage('remolinos'), S: 64, zoom: 2, cl: 1, init: 'content',
    x: null, m: null, v: null, t: 0, P: null, normC: 1, A: [], normS: [], running: false, hist: [[], [], []], snapsAt: [0, 10, 30, 60, 120, 250, 500, 1000] };
  const out = $('#labOut'), chart = $('#labChart');

  function picker(root, list, key, cv) {
    list.forEach(([k, n], i) => { const b = el('button', i === 0 ? 'on' : '', root, n); b.dataset.k = k; });
    segInit(root, d => { st[key] = NST.getImage(d.k); NST.drawSrc(cv, st[key]); resetAll(); });
  }
  picker($('#labContentPick'), [...NST.contentList, ...NST.styleList], 'content', $('#labContent'));
  picker($('#labStylePick'), [...NST.styleList, ...NST.contentList], 'style', $('#labStyle'));
  [['#labContentUp', 'content', '#labContent', '#labContentPick'], ['#labStyleUp', 'style', '#labStyle', '#labStylePick']].forEach(([inp, key, cv, pk]) => {
    $(inp).addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return; st[key] = await NST.loadFile(f);
      $$(pk + ' button').forEach(b => b.classList.remove('on')); NST.drawSrc($(cv), st[key]); resetAll();
    });
  });

  const W = () => ({
    alpha: +$('#labAlpha').value / 10, beta: Math.pow(10, (+$('#labBeta').value - 15) / 10) * (+$('#labBeta').value > 0 ? 1 : 0),
    tv: +$('#labTv').value / 100, lr: +$('#labLr').value * .003,
    layers: $$('.labSL').map(c => c.checked), color: $('#labColor').checked
  });
  function labels() {
    const w = W();
    $('#labAlphaOut').textContent = w.alpha.toFixed(1); $('#labBetaOut').textContent = w.beta < 1 ? w.beta.toFixed(2) : w.beta.toFixed(1);
    $('#labTvOut').textContent = w.tv.toFixed(2); $('#labLrOut').textContent = w.lr.toFixed(3);
  }
  ['#labAlpha', '#labBeta', '#labTv', '#labLr'].forEach(s => $(s).addEventListener('input', labels));
  $$('.labSL').forEach(c => c.addEventListener('change', prepare));
  segInit($('#labCL'), d => { st.cl = +d.l; prepare(); });
  segInit($('#labInit'), d => { st.init = d.i; resetAll(); });
  segInit($('#labRes'), d => { st.S = +d.r; resetAll(); });
  segInit($('#labZoom'), d => { st.zoom = +d.z; prepare(); });

  /* "Capa 0": los propios píxeles + un canal constante. Su Gram 4×4 recoge la media y la covarianza de los colores */
  function colorFeats(x, S) { const N = S * S, F = new Float32Array(4 * N); for (let i = 0; i < 3 * N; i++) F[i] = x[i] - .5; F.fill(1, 3 * N); return F; }
  /* Objetivos: features de contenido y matrices de Gram de estilo */
  function prepare() {
    // La imagen de estilo se recorta según la "escala": ×2 = se usa el centro ampliado, así los trazos se ven más grandes
    const S = st.S, z = st.zoom, crop = document.createElement('canvas'); crop.width = crop.height = 256;
    crop.getContext('2d').drawImage(st.style, 128 - 128 / z, 128 - 128 / z, 256 / z, 256 / z, 0, 0, 256, 256);
    const styleT = NST.toTensor(crop, S);
    const stC = net.forward(NST.toTensor(st.content, S), S), stS = net.forward(styleT, S);
    st.P = stC.a[st.cl]; st.normC = st.P.reduce((s, v) => s + v * v, 0) / st.P.length + 1e-8;
    st.A = []; st.normS = [];
    const F0 = colorFeats(styleT, S); st.A0 = NST.gram(F0, 4, S * S); st.normS0 = st.A0.reduce((a, v) => a + v * v, 0) / 16 / 6; // peso extra: la paleta importa mucho visualmente
    for (let l = 0; l < 3; l++) {
      const s = stS.sizes[l], G = NST.gram(stS.a[l], net.C[l], s * s);
      st.A.push(G); st.normS.push(G.reduce((a, v) => a + v * v, 0) / G.length + 1e-12);
    }
  }
  function initX() {
    const S = st.S, n = 3 * S * S, r = NST.rng((Math.random() * 1e6) | 0);
    if (st.init === 'content') { st.x = NST.toTensor(st.content, S); for (let i = 0; i < n; i++) st.x[i] = Math.max(0, Math.min(1, st.x[i] + r.normal() * .02)); }
    else { st.x = new Float32Array(n); for (let i = 0; i < n; i++) st.x[i] = r(); }
    st.m = new Float32Array(n); st.v = new Float32Array(n); st.t = 0; st.hist = [[], [], []];
    $('#labSnaps').innerHTML = ''; draw();
  }
  function resetAll() { stop(); prepare(); initX(); lineChart(chart, st.hist); }

  /* Una iteración: forward → pérdidas → backward → Adam */
  function iterate() {
    const w = W(), S = st.S, x = st.x, s = net.forward(x, S), dA = [null, null, null];
    // contenido
    const F = s.a[st.cl], n = F.length; let Lc = 0;
    const dc = new Float32Array(n);
    for (let i = 0; i < n; i++) { const d = F[i] - st.P[i]; Lc += d * d; dc[i] = w.alpha * 2 * d / (n * st.normC); }
    Lc /= n * st.normC; dA[st.cl] = dc;
    // estilo
    let Ls = 0; const nl = w.layers.filter(Boolean).length + (w.color ? 1 : 0) || 1;
    let gColor = null;
    if (w.color) { // Gram de color directamente sobre los píxeles
      const N = S * S, F0 = colorFeats(x, S), G0 = NST.gram(F0, 4, N); let L = 0; gColor = new Float32Array(3 * N);
      for (let i = 0; i < 16; i++) { const d = G0[i] - st.A0[i]; L += d * d; }
      Ls += L / (16 * st.normS0) / nl;
      for (let i = 0; i < 3; i++) for (let j = 0; j < 4; j++) {
        const gij = 2 * (G0[i * 4 + j] - st.A0[i * 4 + j]) / (16 * st.normS0) * w.beta / nl * 2 / N;
        for (let q = 0; q < N; q++) gColor[i * N + q] += gij * F0[j * N + q];
      }
    }
    for (let l = 0; l < 3; l++) {
      if (!w.layers[l]) continue;
      const C = net.C[l], sz = s.sizes[l], N = sz * sz, Fl = s.a[l], G = NST.gram(Fl, C, N), A = st.A[l];
      let L = 0; const dG = new Float32Array(C * C);
      for (let i = 0; i < C * C; i++) { const d = G[i] - A[i]; L += d * d; dG[i] = 2 * d / (C * C * st.normS[l]); }
      L /= C * C * st.normS[l]; Ls += L / nl;
      const k = w.beta / nl * 2 / N, dF = dA[l] || new Float32Array(C * N);
      for (let i = 0; i < C; i++) for (let j = 0; j < C; j++) {
        const gij = dG[i * C + j] * k; if (gij === 0) continue;
        const oi = i * N, oj = j * N; for (let q = 0; q < N; q++) dF[oi + q] += gij * Fl[oj + q];
      }
      dA[l] = dF;
    }
    const g = net.backward(s, dA);
    if (gColor) for (let i = 0; i < g.length; i++) g[i] += gColor[i];
    // variación total (suavidad)
    let Ltv = 0;
    if (w.tv > 0) {
      const k = w.tv * 2 / (S * S);
      for (let c = 0; c < 3; c++) for (let y = 0; y < S; y++) for (let xx = 0; xx < S; xx++) {
        const i = c * S * S + y * S + xx;
        if (xx < S - 1) { const d = x[i + 1] - x[i]; Ltv += d * d; g[i] -= k * d; g[i + 1] += k * d; }
        if (y < S - 1) { const d = x[i + S] - x[i]; Ltv += d * d; g[i] -= k * d; g[i + S] += k * d; }
      }
    }
    // Adam
    st.t++; const b1 = .9, b2 = .99, c1 = 1 - Math.pow(b1, st.t), c2 = 1 - Math.pow(b2, st.t);
    for (let i = 0; i < x.length; i++) {
      st.m[i] = b1 * st.m[i] + (1 - b1) * g[i]; st.v[i] = b2 * st.v[i] + (1 - b2) * g[i] * g[i];
      x[i] = Math.max(0, Math.min(1, x[i] - w.lr * (st.m[i] / c1) / (Math.sqrt(st.v[i] / c2) + 1e-8)));
    }
    st.hist[0].push(w.alpha * Lc + 1e-6); st.hist[1].push(w.beta * Ls + 1e-6); st.hist[2].push(w.alpha * Lc + w.beta * Ls + 1e-6);
  }
  function draw() { NST.drawRGB(out, st.x, st.S, false); $('#labIter').textContent = 'iter ' + st.t; }
  function snap() {
    const f = el('figure', '', $('#labSnaps')), cv = el('canvas', '', f); cv.width = cv.height = 72;
    NST.drawRGB(cv, st.x, st.S, false); el('figcaption', '', f, 'iter ' + st.t);
  }
  function frame() {
    if (!st.running) return;
    const t0 = performance.now();
    do { if (st.snapsAt.includes(st.t)) snap(); iterate(); } while (performance.now() - t0 < 45);
    draw(); lineChart(chart, st.hist, { log: true, colors: [NST.css('--content'), NST.css('--style'), NST.css('--total')] });
    if (st.t >= 1500) { stop(); snap(); return; }
    requestAnimationFrame(frame);
  }
  function stop() { st.running = false; $('#labRun').textContent = '▶ Transferir estilo'; $('#labRun').classList.remove('running'); }
  $('#labRun').addEventListener('click', () => {
    if (st.running) { stop(); return; }
    st.running = true; $('#labRun').textContent = '❚❚ Pausa'; $('#labRun').classList.add('running'); requestAnimationFrame(frame);
  });
  $('#labReset').addEventListener('click', resetAll);

  /* Combinaciones de ejemplo: fijan contenido + estilo y arrancan la optimización */
  const COMBOS = [['paisaje', 'remolinos'], ['retrato', 'cubismo'], ['faro', 'acuarela'], ['ciudad', 'neon'],
    ['frutas', 'puntos'], ['flor', 'mosaico'], ['retrato', 'remolinos'], ['faro', 'ondas'], ['paisaje', 'neon'], ['frutas', 'cubismo']];
  const names = Object.fromEntries([...NST.contentList, ...NST.styleList]);
  COMBOS.forEach(([c, s]) => {
    const b = el('button', 'combo', $('#labCombos'));
    [c, s].forEach((k, i) => { const cv = el('canvas', '', b); cv.width = cv.height = 44; NST.drawSrc(cv, NST.getImage(k)); if (!i) el('span', 'plus', b, '+'); });
    el('small', '', b, `${names[c]} + ${names[s]}`);
    b.addEventListener('click', () => {
      st.content = NST.getImage(c); st.style = NST.getImage(s);
      $$('#labContentPick button').forEach(x => x.classList.toggle('on', x.dataset.k === c));
      $$('#labStylePick button').forEach(x => x.classList.toggle('on', x.dataset.k === s));
      $$('#labCombos .combo').forEach(x => x.classList.toggle('on', x === b));
      NST.drawSrc($('#labContent'), st.content); NST.drawSrc($('#labStyle'), st.style); resetAll();
      st.running = true; $('#labRun').textContent = '❚❚ Pausa'; $('#labRun').classList.add('running'); requestAnimationFrame(frame);
    });
  });

  NST.labInit = () => { NST.drawSrc($('#labContent'), st.content); NST.drawSrc($('#labStyle'), st.style); labels(); resetAll(); };
})();
